"""Read-only saved campaign checkpoint audit, no model execution or GPU allocation."""
import hashlib
import json
import math
import sys
from pathlib import Path

import torch
from safetensors.torch import load_file

torch.set_num_threads(2)
root = Path('/capsule/evidence/train')
step = int(sys.argv[1])
assert 25 <= step <= 250 and step % 25 == 0
checkpoint = root / f'checkpoint-{step}'
metadata = json.loads((checkpoint / 'campaign-checkpoint.json').read_text())
assert metadata['step'] == metadata['ema_updates'] == step and metadata['batch'] == 32
assert metadata['run_profile'] == 'campaign250' and not metadata['resume_qualified']
hashes = {}
for relative, expected in metadata['files_sha256'].items():
    path = checkpoint / relative
    path.resolve().relative_to(checkpoint.resolve())
    value = hashlib.sha256(path.read_bytes()).hexdigest()
    assert value == expected
    hashes[relative] = value
optimizer = torch.load(checkpoint / 'optimizer.pt', map_location='cpu', weights_only=True)
steps = sorted({int(state['step']) for state in optimizer['state'].values()})
assert steps == [step] and optimizer['state']
assert all(torch.isfinite(value).all() for state in optimizer['state'].values()
           for value in state.values() if isinstance(value, torch.Tensor))
rates = [group['lr'] for group in optimizer['param_groups']]
assert all(math.isclose(rate, 1e-6, rel_tol=1e-9) for rate in rates)
del optimizer
for relative in ('adapter_model.safetensors', 'sdpo_teacher/adapter_model.safetensors'):
    tensors = load_file(checkpoint / relative, device='cpu')
    assert tensors and all(torch.isfinite(value).all() for value in tensors.values())
    assert any(value.any() for name, value in tensors.items() if 'lora_B' in name)
    del tensors
Path('/audit/result.json').write_text(json.dumps({
    'qualified': True, 'checkpoint_step': step, 'actual_saved_optimizer_moment_steps': steps,
    'actual_saved_optimizer_learning_rates': rates, 'student_teacher_finite_nonzero': True,
    'checkpoint_files_hashes_match': hashes, 'GPU_used': False,
    'scope': 'Actual selected saved checkpoint only. EMA recurrence and exact crash resume not independently qualified.'
}, indent=2) + '\n')
