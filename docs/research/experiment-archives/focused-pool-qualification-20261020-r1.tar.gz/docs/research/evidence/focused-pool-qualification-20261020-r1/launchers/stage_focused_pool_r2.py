import io
import json
import subprocess
import tarfile
from pathlib import Path

root=Path('/home/hammad/projects/worktrees/rl-rft')
local=root/'docs/research/evidence/focused-pool-qualification-20261020-r1'
prepared=local/'prepared-v4'
train=json.loads((root/'scripts/qualification/fixtures/automationbench_train_pool_luna07_v1.json').read_text())['task_names']
heldout=json.loads((root/'scripts/qualification/fixtures/automationbench_heldout62_v1.json').read_text())['task_names']
cases=json.loads((prepared/'source-cases.json').read_text())['cases']
assert {c['row']['task'] for c in cases}==set(train) and len(train)==124 and not set(train)&set(heldout)
remote='/var/lib/posttrain/qualifications/focused-pool-20261020-r2'
ssh=['ssh','-F','/dev/null','-o','BatchMode=yes','-o','IdentitiesOnly=yes','-o','IdentityAgent=none','-o','GSSAPIAuthentication=no','-o','ConnectTimeout=8','-i','/home/hammad/projects/ai-infra/.state/ssh/dstack_worker','dstack@192.168.110.12']
subprocess.run(ssh+['python3','-'],input=f'from pathlib import Path; p=Path({remote!r}); p.mkdir(exist_ok=False); (p/"driver").mkdir(); (p/"evidence").mkdir()',text=True,check=True,timeout=25)
buffer=io.BytesIO()
with tarfile.open(fileobj=buffer,mode='w') as archive:
    for filename in ['qualify_dynamic_context_pair.py','probe_combined_teacher_tool_gradients.py','fit_focused_pool.py','qualify_combined_teacher_contexts.py']:
        archive.add(root/'scripts/qualification'/filename,arcname='driver/'+filename)
    archive.add(prepared,arcname='prepared')
subprocess.run(ssh+['tar','xf','-','-C',remote],input=buffer.getvalue(),check=True,timeout=40)
launcher='''
import hashlib,json,subprocess
from pathlib import Path
r=Path(REMOTE)
files=sorted(p for p in r.rglob('*') if p.is_file())
(r/'source-sha256.txt').write_text(''.join(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+str(p.relative_to(r))+'\\n' for p in files))
name='sdpo-qwen35-4b-focused-pool-cpu-20261020-r2'
assert subprocess.run(['docker','inspect',name],capture_output=True).returncode!=0
cmd=['docker','run','-d','--name',name,'--network','none','--cpus','2','--entrypoint','/usr/bin/timeout',
'-e','PYTHONPATH=/diagnosis/driver:/qualification/driver:/prior/driver:/workspace/driver:/workspace/trl:/workspace/kernel-deps:/workspace/training-deps',
'-e','HF_HUB_OFFLINE=1','-e','TRANSFORMERS_OFFLINE=1','-e','HF_HOME=/hf']
for mount in [f'{r}:/diagnosis:ro',f'{r}/evidence:/evidence','/var/lib/posttrain/qualifications/progress-teacher-124-20261020-r5:/qualification:ro','/var/lib/posttrain/qualifications/sdpo-guidance-five-20261019-experiment03-plain-r3:/prior:ro','/var/lib/posttrain/qualifications/self-campaign-2048-20261017-r5:/workspace:ro','/var/lib/posttrain/cache/huggingface:/hf:ro']:
 cmd+=['-v',mount]
cmd+=['registry.lan/carbonteq/posttrain-lab/posttrain-lab/posttrain-job@sha256:e976e727786135851f4cc96356ebff1f57c75ca5f2d36a2c6aacbf6b2822337'.replace('135851','135f851'),'--signal=TERM','--kill-after=20','600','/opt/posttrain/venv/bin/python','/diagnosis/driver/fit_focused_pool.py','--input','/diagnosis/prepared','--output','/evidence/cpu-fit','--model','/hf/hub/models--Qwen--Qwen3.5-4B/snapshots/851bf6e806efd8d0a36b00ddf55e13ccb7b8cd0a']
identifier=subprocess.check_output(cmd,text=True).strip()
receipt={'container_id':identifier,'name':name,'source_manifest_sha256':hashlib.sha256((r/'source-sha256.txt').read_bytes()).hexdigest(),'gpu_allocated':False,'optimizer_updates':0}
(r/'evidence/cpu-launch-receipt.json').write_text(json.dumps(receipt,indent=2))
print(json.dumps(receipt))
'''.replace('REMOTE',repr(remote))
result=subprocess.run(ssh+['python3','-'],input=launcher,text=True,capture_output=True,timeout=30)
print(result.stdout,result.stderr)
if result.returncode: raise SystemExit(result.returncode)
(local/'cpu-launch-receipt-r2.json').write_text(result.stdout)
