import io,json,subprocess,tarfile
from pathlib import Path

root=Path('/home/hammad/projects/worktrees/rl-rft')
local=root/'docs/research/evidence/focused-pool-qualification-20261020-r1'
prepared=local/'no-copy-ten-r3'
ssh=['ssh','-F','/dev/null','-o','BatchMode=yes','-o','IdentitiesOnly=yes','-o','IdentityAgent=none','-o','GSSAPIAuthentication=no','-o','ConnectTimeout=8','-i','/home/hammad/projects/ai-infra/.state/ssh/dstack_worker','dstack@192.168.110.12']
remote='/var/lib/posttrain/qualifications/focused-no-copy-ten-20261020-r3'
subprocess.run(ssh+['python3','-'],input=f'from pathlib import Path;p=Path({remote!r});p.mkdir(exist_ok=False);(p/"driver").mkdir();(p/"evidence").mkdir()',text=True,check=True,timeout=25)
buffer=io.BytesIO()
with tarfile.open(fileobj=buffer,mode='w') as archive:
    archive.add(prepared,arcname='prepared')
    for name in ['qualify_dynamic_context_pair.py','probe_combined_teacher_tool_gradients.py','qualify_combined_teacher_contexts.py']:
        archive.add(root/'scripts/qualification'/name,arcname='driver/'+name)
subprocess.run(ssh+['tar','xf','-','-C',remote],input=buffer.getvalue(),check=True,timeout=30)
script='''
import fcntl,hashlib,json,subprocess,time
from pathlib import Path
r=Path(REMOTE)
study=Path('/var/lib/posttrain/qualifications/focused-pool-20261020-r1')
deadline=json.loads((study/'evidence/authorization.json').read_text())['deadline_unix']
remaining=int(deadline-time.time()-30)
assert remaining>300
lock=Path('/tmp/sdpo-guidance-five-launch.lock').open('w')
fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
name='sdpo-qwen35-4b-focused-no-copy-ten-20261020-r3'
assert subprocess.run(['docker','inspect',name],capture_output=True).returncode!=0
assert not subprocess.check_output(['docker','ps','-q'],text=True).strip()
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
q=Path('/var/lib/posttrain/qualifications/progress-teacher-124-20261020-r5')
manifest=''.join(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+str(p.relative_to(r))+'\\n' for p in sorted(r.rglob('*')) if p.is_file())
(r/'source-sha256.txt').write_text(manifest)
cmd=['docker','run','-d','--name',name,'--gpus','device=0','--network','none','--shm-size','16g','--entrypoint','/usr/bin/timeout',
'-e','PYTHONPATH=/diagnosis/driver:/local-environment/src:/qualification/driver:/prior/driver:/workspace/driver:/workspace/trl:/workspace/kernel-deps:/workspace/training-deps',
'-e','HF_HUB_OFFLINE=1','-e','TRANSFORMERS_OFFLINE=1','-e','HF_HOME=/hf','-e','VLLM_BATCH_INVARIANT=1','-e','VLLM_GDN_DECODE_KERNEL=triton','-e','TOKENIZERS_PARALLELISM=false','-e','WANDB_DISABLED=true','-e','TRITON_CACHE_DIR=/triton']
for binding in [f'{r}:/diagnosis:ro',f'{r}/evidence:/evidence',f'{q}:/qualification:ro',f'{q}/environment:/local-environment:ro','/var/lib/posttrain/qualifications/sdpo-guidance-five-20261019-experiment03-plain-r3:/prior:ro','/var/lib/posttrain/qualifications/self-campaign-2048-20261017-r5:/workspace:ro','/var/lib/posttrain/cache/huggingface:/hf:ro','/var/lib/posttrain/cache/triton:/triton']:
 cmd+=['-v',binding]
cmd+=['registry.lan/carbonteq/posttrain-lab/posttrain-lab/posttrain-job@sha256:e976e727786135f851f4cc96356ebff1f57c75ca5f2d36a2c6aacbf6b2822337','--signal=TERM','--kill-after=30',str(remaining),'/opt/posttrain/venv/bin/python','/diagnosis/driver/qualify_dynamic_context_pair.py','--reference','/diagnosis/prepared','--contexts','/diagnosis/prepared','--model','/hf/hub/models--Qwen--Qwen3.5-4B/snapshots/851bf6e806efd8d0a36b00ddf55e13ccb7b8cd0a','--output','/evidence/run','--focused','--all-cases','--candidate-only','--candidate-file','candidate-supplement.txt','--native-source-proof']
identifier=subprocess.check_output(cmd,text=True).strip()
receipt={'name':name,'container_id':identifier,'source_manifest_sha256':hashlib.sha256(manifest.encode()).hexdigest(),'deadline_unix':deadline,'optimizer_updates':0,'new_budget':False,'changes':'omit failed candidate draft prose from teacher review summary plus explicit prohibition emphasis; original action tokens and native states unchanged','tasks':json.loads((r/'prepared/precommit.json').read_text())['tasks']}
(r/'evidence/launch-receipt.json').write_text(json.dumps(receipt,indent=2))
print(json.dumps(receipt))
'''.replace('REMOTE',repr(remote))
result=subprocess.run(ssh+['python3','-'],input=script,text=True,capture_output=True,timeout=30)
print(result.stdout,result.stderr)
if result.returncode:raise SystemExit(result.returncode)
(local/'no-copy-ten-launch-r3.json').write_text(result.stdout)
