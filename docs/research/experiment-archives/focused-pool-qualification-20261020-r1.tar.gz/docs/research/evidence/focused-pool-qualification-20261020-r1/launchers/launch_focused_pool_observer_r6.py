import io,json,subprocess,tarfile
from pathlib import Path

root=Path('/home/hammad/projects/worktrees/rl-rft')
local=root/'docs/research/evidence/focused-pool-qualification-20261020-r1'
ssh=['ssh','-F','/dev/null','-o','BatchMode=yes','-o','IdentitiesOnly=yes','-o','IdentityAgent=none','-o','GSSAPIAuthentication=no','-o','ConnectTimeout=8','-i','/home/hammad/projects/ai-infra/.state/ssh/dstack_worker','dstack@192.168.110.12']
remote='/var/lib/posttrain/qualifications/focused-pool-observer-20261020-r6'
subprocess.run(ssh+['python3','-'],input=f'from pathlib import Path;p=Path({remote!r});p.mkdir(exist_ok=False);(p/"driver").mkdir();(p/"evidence").mkdir()',text=True,check=True,timeout=25)
buffer=io.BytesIO()
with tarfile.open(fileobj=buffer,mode='w') as archive:
    for name in ['audit_focused_teacher_proposals.py','qualify_combined_teacher_contexts.py']:
        archive.add(root/'scripts/qualification'/name,arcname='driver/'+name)
subprocess.run(ssh+['tar','xf','-','-C',remote],input=buffer.getvalue(),check=True,timeout=25)
script='''
import hashlib,json,subprocess,time
from pathlib import Path
r=Path(REMOTE)
study=Path('/var/lib/posttrain/qualifications/focused-pool-20261020-r2')
deadline=json.loads((study/'evidence/authorization.json').read_text())['deadline_unix']
remaining=int(deadline-time.time()-30)
assert remaining>120
name='sdpo-focused-pool-observer-20261020-r6'
assert subprocess.run(['docker','inspect',name],capture_output=True).returncode!=0
manifest=''.join(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+str(p.relative_to(r))+'\\n' for p in sorted((r/'driver').glob('*.py')))
(r/'source-sha256.txt').write_text(manifest)
cmd=['docker','run','-d','--name',name,'--cpus','2','--network','none','--entrypoint','/usr/bin/timeout',
'-e','PYTHONPATH=/diagnosis/driver:/local-environment/src:/qualification/driver:/prior/driver:/workspace/driver:/workspace/trl:/workspace/kernel-deps:/workspace/training-deps',
'-e','HF_HUB_OFFLINE=1','-e','TRANSFORMERS_OFFLINE=1']
for binding in [f'{r}:/diagnosis:ro',f'{r}/evidence:/evidence',f'{study}:/study:ro','/var/lib/posttrain/qualifications/progress-teacher-124-20261020-r5:/qualification:ro','/var/lib/posttrain/qualifications/progress-teacher-124-20261020-r5/environment:/local-environment:ro','/var/lib/posttrain/qualifications/sdpo-guidance-five-20261019-experiment03-plain-r3:/prior:ro','/var/lib/posttrain/qualifications/self-campaign-2048-20261017-r5:/workspace:ro']:
 cmd+=['-v',binding]
cmd+=['registry.lan/carbonteq/posttrain-lab/posttrain-lab/posttrain-job@sha256:e976e727786135f851f4cc96356ebff1f57c75ca5f2d36a2c6aacbf6b2822337','--signal=TERM','--kill-after=30',str(remaining),'/opt/posttrain/venv/bin/python','/diagnosis/driver/audit_focused_teacher_proposals.py','--prepared','/study/prepared','--run','/study/evidence/run','--materials','/qualification/evidence/cpu/materials.json','--output','/evidence/audit']
identifier=subprocess.check_output(cmd,text=True).strip()
result={'container_id':identifier,'name':name,'source_manifest_sha256':hashlib.sha256(manifest.encode()).hexdigest(),'deadline_unix':deadline,'gpu_allocated':False,'model_calls':0,'optimizer_updates':0,'measurement':'new exact-captured historical replay; original GPU artifacts unchanged'}
(r/'evidence/launch-receipt.json').write_text(json.dumps(result,indent=2))
print(json.dumps(result))
'''.replace('REMOTE',repr(remote))
result=subprocess.run(ssh+['python3','-'],input=script,text=True,capture_output=True,timeout=30)
print(result.stdout,result.stderr)
if result.returncode:raise SystemExit(result.returncode)
(local/'observer-launch-receipt-r6.json').write_text(result.stdout)
