import json
import subprocess
from pathlib import Path

local=Path('/home/hammad/projects/worktrees/rl-rft/docs/research/evidence/focused-pool-qualification-20261020-r1')
ssh=['ssh','-F','/dev/null','-o','BatchMode=yes','-o','IdentitiesOnly=yes','-o','IdentityAgent=none','-o','GSSAPIAuthentication=no','-o','ConnectTimeout=8','-i','/home/hammad/projects/ai-infra/.state/ssh/dstack_worker','dstack@192.168.110.12']
script='''
import fcntl,hashlib,json,subprocess,time
from pathlib import Path
root=Path('/var/lib/posttrain/qualifications/focused-pool-20261020-r2')
name='sdpo-qwen35-4b-focused-pool-qualify-20261020-r2'
lock=Path('/tmp/sdpo-guidance-five-launch.lock').open('w')
fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
assert subprocess.run(['docker','inspect',name],capture_output=True).returncode!=0
assert not (root/'evidence/run').exists()
assert not subprocess.check_output(['docker','ps','-q'],text=True).strip()
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
cpu=json.loads((root/'evidence/cpu-fit/receipt.json').read_text())
assert cpu['cpu_template_qualified'] and cpu['tasks']==124 and not cpu['failures']
assert hashlib.sha256((root/'source-sha256.txt').read_bytes()).hexdigest()=='d714db9d2c20dcb3e88af8fa55e2a89ff20d0a0d86bbf8079e359b92daa433b9'
subprocess.run(['sha256sum','-c','source-sha256.txt'],cwd=root,check=True,stdout=subprocess.DEVNULL)
q=Path('/var/lib/posttrain/qualifications/progress-teacher-124-20261020-r5')
assert hashlib.sha256((q/'source-sha256.txt').read_bytes()).hexdigest()=='4eaf090a4201f0d14b3c6efcb0c4b07541ffcc4e47224cc9f14fca427c019f85'
start=time.time()
deadline=1792498766.765345
assert deadline-start>600
authorization={'user_authorized':'Fresh two-hour qualification after CPU audit, no training updates','started_unix':1792491566.765345,'phase_started_unix':start,'deadline_unix':deadline,'new_budget':False,'scope':'124candidate teacher continuations/native next-decision replays and conditional reference gradient measurements; not automatic semantic approval','unlocalized_cases':15,'training_restarted':False}
(root/'evidence/authorization.json').write_text(json.dumps(authorization,indent=2))
cmd=['docker','run','-d','--name',name,'--gpus','device=0','--network','none','--shm-size','16g','--entrypoint','/usr/bin/timeout',
'-e','PYTHONPATH=/diagnosis/driver:/local-environment/src:/qualification/driver:/prior/driver:/workspace/driver:/workspace/trl:/workspace/kernel-deps:/workspace/training-deps',
'-e','HF_HUB_OFFLINE=1','-e','TRANSFORMERS_OFFLINE=1','-e','HF_HOME=/hf','-e','VLLM_BATCH_INVARIANT=1','-e','VLLM_GDN_DECODE_KERNEL=triton','-e','TOKENIZERS_PARALLELISM=false','-e','WANDB_DISABLED=true','-e','TRITON_CACHE_DIR=/triton']
for binding in [f'{root}:/diagnosis:ro',f'{root}/evidence:/evidence',f'{q}:/qualification:ro',f'{q}/environment:/local-environment:ro','/var/lib/posttrain/qualifications/sdpo-guidance-five-20261019-experiment03-plain-r3:/prior:ro','/var/lib/posttrain/qualifications/self-campaign-2048-20261017-r5:/workspace:ro','/var/lib/posttrain/cache/huggingface:/hf:ro','/var/lib/posttrain/cache/triton:/triton']:
 cmd+=['-v',binding]
cmd+=['registry.lan/carbonteq/posttrain-lab/posttrain-lab/posttrain-job@sha256:e976e727786135f851f4cc96356ebff1f57c75ca5f2d36a2c6aacbf6b2822337','--signal=TERM','--kill-after=30',str(int(deadline-time.time()-30)),'/opt/posttrain/venv/bin/python','/diagnosis/driver/qualify_dynamic_context_pair.py','--reference','/diagnosis/prepared','--contexts','/diagnosis/prepared','--model','/hf/hub/models--Qwen--Qwen3.5-4B/snapshots/851bf6e806efd8d0a36b00ddf55e13ccb7b8cd0a','--output','/evidence/run','--focused','--all-cases','--candidate-only','--candidate-file','candidate-supplement.txt','--native-source-proof']
identifier=subprocess.check_output(cmd,text=True).strip()
receipt={'name':name,'container_id':identifier,'source_manifest_sha256':'d714db9d2c20dcb3e88af8fa55e2a89ff20d0a0d86bbf8079e359b92daa433b9','authorization':authorization,'optimizer_updates':0,'actual_candidate_context':'focused deterministic corpus + localized feedback; legacy internal mode deepseek is a loader label only, no DeepSeek inference'}
(root/'evidence/launch-receipt.json').write_text(json.dumps(receipt,indent=2))
print(json.dumps(receipt))
'''
result=subprocess.run(ssh+['python3','-'],input=script,text=True,capture_output=True,timeout=30)
print(result.stdout,result.stderr)
if result.returncode: raise SystemExit(result.returncode)
(local/'gpu-launch-receipt-r2.json').write_text(result.stdout)
