import io
import json
import subprocess
import tarfile
from pathlib import Path

root=Path('/home/hammad/projects/worktrees/rl-rft')
local=root/'docs/research/evidence/focused-pool-qualification-20261020-r1'
ssh=['ssh','-F','/dev/null','-o','BatchMode=yes','-o','IdentitiesOnly=yes','-o','IdentityAgent=none','-o','GSSAPIAuthentication=no','-o','ConnectTimeout=8','-i','/home/hammad/projects/ai-infra/.state/ssh/dstack_worker','dstack@192.168.110.12']
remote='/var/lib/posttrain/qualifications/focused-bad-spans-20261020-r5'
subprocess.run(ssh+['python3','-'],input=f'from pathlib import Path;p=Path({remote!r});p.mkdir(exist_ok=False);(p/"driver").mkdir();(p/"evidence").mkdir()',text=True,check=True,timeout=25)
buffer=io.BytesIO()
with tarfile.open(fileobj=buffer,mode='w') as archive:
    archive.add(local/'no-copy-ten-r3',arcname='prepared')
    for name in ['probe_focused_localized_spans.py','qualify_combined_teacher_contexts.py']:
        archive.add(root/'scripts/qualification'/name,arcname='driver/'+name)
subprocess.run(ssh+['tar','xf','-','-C',remote],input=buffer.getvalue(),check=True,timeout=30)
script='''
import fcntl,hashlib,json,subprocess,time
from pathlib import Path
r=Path(REMOTE)
deadline=1792498766.765345
assert deadline-time.time()>300
manifest=''.join(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+str(p.relative_to(r))+'\\n' for p in sorted(r.rglob('*')) if p.is_file())
(r/'source-sha256.txt').write_text(manifest)
base=['docker','run','--network','none','--cpus','2','--entrypoint','/usr/bin/timeout',
'-e','PYTHONPATH=/diagnosis/driver:/local-environment/src:/qualification/driver:/prior/driver:/workspace/driver:/workspace/trl:/workspace/kernel-deps:/workspace/training-deps',
'-e','HF_HUB_OFFLINE=1','-e','TRANSFORMERS_OFFLINE=1','-e','HF_HOME=/hf','-e','TOKENIZERS_PARALLELISM=false']
for mount in [f'{r}:/diagnosis:ro',f'{r}/evidence:/evidence','/var/lib/posttrain/qualifications/progress-teacher-124-20261020-r5:/qualification:ro','/var/lib/posttrain/qualifications/progress-teacher-124-20261020-r5/environment:/local-environment:ro','/var/lib/posttrain/qualifications/focused-pool-20261020-r2:/control:ro','/var/lib/posttrain/qualifications/sdpo-guidance-five-20261019-experiment03-plain-r3:/prior:ro','/var/lib/posttrain/qualifications/self-campaign-2048-20261017-r5:/workspace:ro','/var/lib/posttrain/cache/huggingface:/hf:ro']:
 base+=['-v',mount]
image='registry.lan/carbonteq/posttrain-lab/posttrain-lab/posttrain-job@sha256:e976e727786135f851f4cc96356ebff1f57c75ca5f2d36a2c6aacbf6b2822337'
args=['/opt/posttrain/venv/bin/python','/diagnosis/driver/probe_focused_localized_spans.py','--model','/hf/hub/models--Qwen--Qwen3.5-4B/snapshots/851bf6e806efd8d0a36b00ddf55e13ccb7b8cd0a','--adapter','/control/evidence/run/rollout-policy-v0','--prepared','/diagnosis/prepared']
cpu=base[:2]+['--name','sdpo-focused-bad-spans-cpu-20261020-r5']+base[2:]+[image,'--signal=TERM','--kill-after=10','120']+args+['--output','/evidence/cpu','--preflight-only']
result=subprocess.run(cpu,text=True,capture_output=True,timeout=140)
(r/'evidence/cpu-stdout.txt').write_text(result.stdout);(r/'evidence/cpu-stderr.txt').write_text(result.stderr)
assert result.returncode==0,(result.stdout,result.stderr)
assert json.loads((r/'evidence/cpu/receipt.json').read_text())['passed']
lock=Path('/tmp/sdpo-guidance-five-launch.lock').open('w');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
assert not subprocess.check_output(['docker','ps','-q'],text=True).strip()
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
name='sdpo-qwen35-4b-focused-bad-spans-20261020-r5'
assert subprocess.run(['docker','inspect',name],capture_output=True).returncode!=0
command=base[:2]+['-d','--name',name,'--gpus','device=0','--shm-size','16g']+base[2:]+[image,'--signal=TERM','--kill-after=30',str(int(deadline-time.time()-30))]+args+['--output','/evidence/run']
identifier=subprocess.check_output(command,text=True).strip()
receipt={'container_id':identifier,'name':name,'deadline_unix':deadline,'optimizer_updates':0,'source_manifest_sha256':hashlib.sha256(manifest.encode()).hexdigest(),'hypothesis':'Whole generated-reference projections can conceal reinforcement of explicitly forbidden original spans. Compare full-draft and no-copy contexts on EXACT SAME original localized bad token positions. No optimizer or generated target in loss.'}
(r/'evidence/launch-receipt.json').write_text(json.dumps(receipt,indent=2));print(json.dumps(receipt))
'''.replace('REMOTE',repr(remote))
result=subprocess.run(ssh+['python3','-'],input=script,text=True,capture_output=True,timeout=165)
print(result.stdout,result.stderr)
if result.returncode:raise SystemExit(result.returncode)
(local/'bad-span-launch-r5.json').write_text(result.stdout)
