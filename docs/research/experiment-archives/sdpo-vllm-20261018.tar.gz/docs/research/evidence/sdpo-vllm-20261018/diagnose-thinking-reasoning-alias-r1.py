"""Test exact native reasoning alias normalization; do not change run artifacts."""

import copy
import json
from pathlib import Path

from sdpo_prompting import prompt_ids
from transformers import AutoTokenizer
from vllm.entrypoints.openai.chat_completion.protocol import ChatCompletionRequest

root = Path('/capsule/evidence/run')
tokenizer = AutoTokenizer.from_pretrained(
    '/hf/hub/models--Qwen--Qwen3.5-4B/snapshots/851bf6e806efd8d0a36b00ddf55e13ccb7b8cd0a',
    local_files_only=True,
)
selected = {r['generation_index']: r for r in
            json.loads((root / 'step-0001/online_train/selected-transitions.json').read_text())}
results = []
with (root / 'step-0001/online_train/generation-calls.jsonl').open() as stream:
    for index, line in enumerate(stream):
        if index not in selected:
            continue
        call, row = json.loads(line), selected[index]
        restored = copy.deepcopy(call['messages'])
        restored_count = 0
        for message in restored:
            if message['role'] == 'assistant' and 'reasoning' in message and 'reasoning_content' not in message:
                assert isinstance(message['reasoning'], str)
                message['reasoning_content'] = message.pop('reasoning')
                restored_count += 1
        original_match = prompt_ids(tokenizer, call['messages'], call['tools'], thinking=True) == call['prefix_ids']
        restored_match = prompt_ids(tokenizer, restored, call['tools'], thinking=True) == call['prefix_ids']
        teacher_match = prompt_ids(tokenizer, restored + [{'role': 'user', 'content': row['teacher_feedback']}],
                                   call['tools'], thinking=True) == row['teacher_prefix_ids']
        before = copy.deepcopy(restored)
        ChatCompletionRequest(model='local-self', messages=restored, tools=call['tools'],
                              chat_template_kwargs={'enable_thinking': True})
        alias_normalized = all(
            ('reasoning_content' not in after and after.get('reasoning') == prior['reasoning_content'])
            for prior, after in zip(before, restored, strict=True) if 'reasoning_content' in prior)
        results.append({'task': row['task'], 'generation_index': index,
                        'original_rerender_match': original_match,
                        'restored_rerender_match': restored_match,
                        'teacher_after_restoration_matches_actual': teacher_match,
                        'restored_history_messages': restored_count,
                        'actual_protocol_constructor_normalizes_alias': alias_normalized})
Path('/audit-results/reasoning-alias-diagnosis.json').write_text(json.dumps(results, indent=2) + '\n')
