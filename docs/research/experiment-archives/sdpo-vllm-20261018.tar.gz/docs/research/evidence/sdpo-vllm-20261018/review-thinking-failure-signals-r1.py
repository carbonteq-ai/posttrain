"""Read four actually trained failed actions, their feedback and saved Adam evidence."""

import json
from pathlib import Path

from transformers import AutoTokenizer

root = Path('/capsule/evidence/run')
tokenizer = AutoTokenizer.from_pretrained(
    '/hf/hub/models--Qwen--Qwen3.5-4B/snapshots/851bf6e806efd8d0a36b00ddf55e13ccb7b8cd0a',
    local_files_only=True,
)
candidates = []
for step in range(6, 0, -1):
    folder = root / f'step-{step:04d}/online_train'
    directions = {(r['task'], r['generation_index']): r for r in
                  json.loads((folder / 'teacher-adam-directions.json').read_text())}
    for row in json.loads((folder / 'selected-transitions.json').read_text()):
        if row['native_success'] != 0:
            continue
        category = 0 if row['observed_tool_error'] else 1 if row['terminal_text'] else 2
        candidates.append((category, -step, row, directions[(row['task'], row['generation_index'])]))
candidates.sort(key=lambda item: item[:2])
cases, tasks = [], set()
for category, negative_step, row, direction in candidates:
    if row['task'] in tasks:
        continue
    tasks.add(row['task'])
    advantage = direction['teacher_sampled_advantages']
    delta = direction['actual_adam_logprob_deltas']
    assert len(advantage) == len(delta) == len(row['action_ids'])
    cases.append({'task': row['task'], 'step': -negative_step, 'episode_id': row['episode_id'],
                  'generation_index': row['generation_index'], 'native_success': row['native_success'],
                  'selection_category': ['native_tool_error', 'failed_terminal', 'other_failed_action'][category],
                  'action': tokenizer.decode(row['action_ids'], skip_special_tokens=False),
                  'teacher_feedback': row['teacher_feedback'], 'solution_used': row['solution_used'],
                  'reference_episode_id': row['reference_episode_id'],
                  'tokenwise_teacher_argmax': tokenizer.decode(direction['teacher_support_diagnostic']['teacher_top1_ids']),
                  'action_tokens': len(advantage), 'mean_teacher_sampled_advantage': sum(advantage) / len(advantage),
                  'sum_actual_adam_logprob_delta': sum(delta),
                  'token_sign_agreement_fraction': direction['sign_agreement_fraction'],
                  'scope': 'Actual source failed trajectory and actual full-batch Adam scores. '
                           'Tokenwise teacher argmax is not a generated repair; local direction is not task correctness.'})
    if len(cases) == 4:
        break
assert len(cases) == 4
Path('/audit-results/four-thinking-failure-signals.json').write_text(json.dumps(cases, indent=2) + '\n')
