"""Read-only CPU extraction of four actually selected error-bearing actions."""

import json
from pathlib import Path

from transformers import AutoTokenizer

root = Path('/capsule/evidence/run/control')
tokenizer = AutoTokenizer.from_pretrained(
    '/hf/hub/models--Qwen--Qwen3.5-4B/snapshots/851bf6e806efd8d0a36b00ddf55e13ccb7b8cd0a',
    local_files_only=True,
)
cases, seen = [], set()
for step in range(1, 7):
    folder = root / f'step-{step:04d}' / 'online_train'
    rows = json.loads((folder / 'selected-transitions.json').read_text())
    directions = {(r['task'], r['generation_index']): r for r in
                  json.loads((folder / 'teacher-adam-directions.json').read_text())}
    for row in rows:
        if not row['observed_tool_error'] or row['task'] in seen:
            continue
        seen.add(row['task'])
        direction = directions[(row['task'], row['generation_index'])]
        advantages = direction['teacher_sampled_advantages']
        deltas = direction['actual_adam_logprob_deltas']
        assert len(advantages) == len(deltas) == len(row['action_ids'])
        support = direction['teacher_support_diagnostic']
        action = tokenizer.decode(row['action_ids'], skip_special_tokens=False)
        feedback_start = row['teacher_feedback'].index('{')
        feedback, _ = json.JSONDecoder().raw_decode(row['teacher_feedback'][feedback_start:])
        literal = {
            'operations.fire_suppression_testing': 'FIRE\n</parameter>',
            'hr.offboarding_automation': '<parameter=id>\n\n</parameter>',
            'operations.calendly_equipment_inspection': 'meetings/demo',
            'hr.benefits_enrollment_review': 'Benefits Enrollment Queue (ss_benefits_5134)',
        }.get(row['task'])
        span = None
        if literal is not None:
            start = action.index(literal)
            end = start + len(literal)
            boundaries = [len(tokenizer.decode(row['action_ids'][:i], skip_special_tokens=False))
                          for i in range(len(row['action_ids']) + 1)]
            indices = [i for i in range(len(advantages)) if boundaries[i] < end and boundaries[i + 1] > start]
            assert indices
            span = {'literal': literal, 'token_indices': indices,
                    'mean_teacher_sampled_advantage': sum(advantages[i] for i in indices) / len(indices),
                    'sum_actual_adam_logprob_delta': sum(deltas[i] for i in indices),
                    'teacher_argmax_same_token_fraction': sum(
                        support['teacher_top1_ids'][i] == row['action_ids'][i] for i in indices) / len(indices),
                    'scope': 'Observed error-associated argument span, not an independently scored correct replacement.'}
        cases.append({
            'task': row['task'], 'step': step, 'episode_id': row['episode_id'],
            'generation_index': row['generation_index'], 'native_success': row['native_success'],
            'action': action, 'error_associated_span': span,
            'teacher_feedback': row['teacher_feedback'],
            'executed_tool_response_count': row['executed_tool_responses'],
            'observed_tool_responses': feedback['observed_tool_responses'],
            'tokenwise_teacher_argmax': tokenizer.decode(support['teacher_top1_ids']),
            'action_token_count': len(advantages),
            'mean_teacher_sampled_advantage': sum(advantages) / len(advantages),
            'mean_actual_adam_sampled_logprob_delta': sum(deltas) / len(deltas),
            'token_sign_agreement_fraction': direction['sign_agreement_fraction'],
            'scope': 'Tokenwise teacher argmax is not an autoregressively generated repair. '
                     'Sign alignment and action-average changes are not correctness or reward proof.',
        })
        if len(cases) == 4:
            break
    if len(cases) == 4:
        break
assert len(cases) == 4
Path('/audit-results/four-error-action-signals.json').write_text(json.dumps(cases, indent=2) + '\n')
