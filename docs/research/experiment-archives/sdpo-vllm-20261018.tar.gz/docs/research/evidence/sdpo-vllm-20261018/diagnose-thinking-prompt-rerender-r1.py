"""Read-only diagnosis of a native-message re-render discrepancy; no pass claim."""

import json
from pathlib import Path

from sdpo_prompting import prompt_ids
from transformers import AutoTokenizer

root = Path('/capsule/evidence/run')
tokenizer = AutoTokenizer.from_pretrained(
    '/hf/hub/models--Qwen--Qwen3.5-4B/snapshots/851bf6e806efd8d0a36b00ddf55e13ccb7b8cd0a',
    local_files_only=True,
)
selected = {r['generation_index']: r for r in
            json.loads((root / 'step-0001/online_train/selected-transitions.json').read_text())}
results = []
with (root / 'step-0001/online_train/generation-calls.jsonl').open() as stream:
    for index, line in enumerate(stream):
        if index not in selected:
            continue
        call, row = json.loads(line), selected[index]
        student = prompt_ids(tokenizer, call['messages'], call['tools'], thinking=True)
        teacher = prompt_ids(tokenizer, call['messages'] + [{'role': 'user', 'content': row['teacher_feedback']}],
                             call['tools'], thinking=True)
        original = call['prefix_ids']
        if student != original:
            pos = next((i for i, (a, b) in enumerate(zip(student, original, strict=False)) if a != b),
                       min(len(student), len(original)))
            results.append({'task': row['task'], 'generation_index': index,
                'selected_matches_original_prefix': row['student_prefix_ids'] == original,
                'selected_matches_original_action': row['action_ids'] == call['action_ids'],
                'original_length': len(original), 'rerendered_length': len(student), 'first_difference': pos,
                'original_near_difference': tokenizer.decode(original[max(0, pos-40):pos+100]),
                'rerendered_near_difference': tokenizer.decode(student[max(0, pos-40):pos+100]),
                'teacher_rerender_matches': teacher == row['teacher_prefix_ids'],
                'message_fields': [list(m) for m in call['messages']]})
Path('/audit-results/prompt-rerender-diagnosis.json').write_text(json.dumps(results, indent=2) + '\n')
