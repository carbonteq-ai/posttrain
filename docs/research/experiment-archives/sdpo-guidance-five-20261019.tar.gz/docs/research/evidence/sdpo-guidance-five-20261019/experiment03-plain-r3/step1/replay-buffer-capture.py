"""CPU reproduction of the native Buffer capture boundary and compact receipts."""
import copy
import hashlib
import inspect
import json
import traceback
from datetime import datetime
from pathlib import Path
from types import SimpleNamespace

import automationbench_v1.limited_tools as limited

toolset = next(value for value in vars(limited).values()
               if isinstance(value, type) and 'invoke' in value.__dict__)
episodes = [json.loads(line) for line in Path('/evidence/run/step-0001/online_train/native/traces.jsonl').open()]
episodes = [e for e in episodes if e['task']['data']['name'] == 'simple.buffer_company_award']
state = SimpleNamespace(world=copy.deepcopy(episodes[0]['task']['data']['initial_state']), capture_actions=True)
original = copy.deepcopy(state.world)
owner = SimpleNamespace(state=state, config=SimpleNamespace(allowed_tools=['buffer_add_to_queue']))
try:
    response = toolset.invoke(owner, 'buffer_add_to_queue', organization_id='org_001',
        channel_id='ch_facebook', method='schedule', text='BrightPath Forbes gratitude.',
        scheduled_at=datetime.fromisoformat('2026-10-09T14:00:00+05:00'))
    reproduction = {'returned': response}
except Exception as error:
    reproduction = {'raised_type': type(error).__name__, 'message': str(error),
        'frames': [{'file': Path(frame.filename).name, 'line': frame.lineno, 'function': frame.name}
                   for frame in traceback.extract_tb(error.__traceback__)]}
reproduction['stored_world_unchanged'] = state.world == original
compact = []
for episode in episodes:
    trace = episode['traces'][0]
    calls = []
    for event in trace['tool_execution_events']:
        if event.get('source') != 'tool_server':
            continue
        receipt = json.loads(event['receipt_json'])
        if receipt['tool_name'] != 'buffer_add_to_queue' or receipt['phase'] == 'dispatch':
            continue
        arguments = json.loads(receipt['arguments_json'])['kwargs']
        error = json.loads(receipt['error_json']) if receipt.get('error_json') else None
        calls.append({'phase': receipt['phase'], 'method': arguments.get('method'),
                      'scheduled_at': arguments.get('scheduled_at'), 'error': error,
                      'state_persistence': receipt['state_persistence'],
                      'state_read_revision': receipt.get('state_read_revision'),
                      'state_write_revision': receipt.get('state_write_revision')})
    compact.append({'episode_id': episode['id'], 'native_success': trace['metrics']['task_completed_correctly'],
                    'stop': trace['stop_condition'], 'calls': calls})
print(json.dumps({'reproduction': reproduction, 'native_receipts': compact,
    'invoke_source_sha256': hashlib.sha256(inspect.getsource(toolset.invoke).encode()).hexdigest(),
    'model_calls': 0, 'optimizer_updates': 0,
    'scope': 'The same pinned invoke/capture boundary with typed datetime on copied state. '
             'Underlying tool replay is separate. No fixture or running source changes.'}, indent=2))
