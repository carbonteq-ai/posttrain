"""Stage only the authorized plain03 sampler comparison; never launch here."""
import datetime
import hashlib
import json
import shutil
import subprocess
import time
from pathlib import Path

base = Path('/var/lib/posttrain/qualifications')
source = base / 'sdpo-guidance-five-20261019-experiment02-plain-r4'
destination = base / 'sdpo-guidance-five-20261019-experiment03-plain-r3'
run_name = 'sdpo-qwen35-4b-guidance-five-exp03-20261019-r3'
state = json.loads(subprocess.check_output([
    'docker', 'inspect', 'sdpo-qwen35-4b-guidance-five-exp02-20261019-r4',
    '--format', '{{json .State}}']))
assert state['Status'] == 'exited' and not state['Running']
assert not subprocess.check_output(['nvidia-smi', '--query-compute-apps=pid', '--format=csv,noheader']).strip()
assert subprocess.run(['docker', 'inspect', run_name], capture_output=True).returncode != 0
assert not destination.exists()
subprocess.run(['sha256sum', '-c', 'source-sha256.txt'], cwd=source,
               stdout=subprocess.DEVNULL, check=True)
registry = json.loads((base / 'sdpo-guidance-five-20261019-executions.json').read_text())
previous = [a for a in registry['attempts'] if a['number'] == 3]
assert previous[-1]['run_name'] == 'sdpo-qwen35-4b-guidance-five-exp03-20261019-r2'
for attempt in previous:
    old = json.loads(subprocess.check_output(['docker', 'inspect', attempt['run_name'], '--format', '{{json .State}}']))
    assert old['Status'] == 'exited' and not old['Running']
    assert not (Path(attempt['capsule']) / 'evidence/run/updates.json').exists()

started = time.time()
destination.mkdir()
for path in source.iterdir():
    if path.name in ('evidence', 'source-sha256.txt', '__pycache__'):
        continue
    target = destination / path.name
    if path.is_dir():
        shutil.copytree(path, target, ignore=shutil.ignore_patterns('__pycache__'))
    else:
        shutil.copyfile(path, target)
(destination / 'evidence').mkdir()
shared = base / 'sdpo-guidance-five-20261019-shared-plain-base02-r4'
assert hashlib.sha256((shared / 'reference.json').read_bytes()).hexdigest() == '4ad42c5d5a10a35ca66d75acfeadd0823f6b55dd341c059ccd643b50355fc2b0'
shutil.copytree(shared, destination / 'baseline')
c = json.loads((source / 'experiment.json').read_text())
for key in ('requested_budget_exception', 'no_learning_launch_without_budget_decision',
            'original_experiment_deadline_utc', 'reason_budget_needed',
            'actual_updates_already_applied_in_logical02', 'campaign_actual_updates',
            'qualification_evidence', 'source_capsule', 'preflight_scope',
            'staging_history', 'qualified_source_manifest_sha256'):
    c.pop(key, None)
c.update(number=3, run_name=run_name,
    hypothesis='Earliest observed API-error or public-schema-risk selection improves native corrective behavior relative to the matched feedback-only first-error control.',
    falsifier='No native corrective improvement or worse successful-task retention, incomplete native coverage, failed fidelity/repeatability, or misleading teacher/Adam direction rejects the rescue. Risk is not correctness credit.',
    selection_mode='first-risk-frontier',
    decision_evidence=['experiment03-plain-protocol.json', 'experiment02-plain-r4/step1/decision-review.json',
                       'experiment02-plain-r4/step1/risk-selection-replay.json'],
    context_selection_scope='TRAIN-only prospective selection comparison frozen before02postreadout; no heldout outcome adaptation.',
    budget_window_started_unix=started, experiment_deadline_unix=started + 7140,
    zero_update_repair_of=previous[-1]['run_name'],
    repair_evidence={'qualification': 'mtp-gate-receipt.json', 'mixed': 'mixed-gate-receipt.json',
                     'native_preflight': 'native-preflight.json', 'scope': 'User-authorized plain decoding after preserved zero-update MTP failures.'},
    shared_heldout_base=True,
    shared_base_reference_sha256='4ad42c5d5a10a35ca66d75acfeadd0823f6b55dd341c059ccd643b50355fc2b0')
c['profile']['selection_mode'] = 'first-risk-frontier'
c['profile']['teacher_context'] = 'feedback-only-null-task-guide-matched-shell-v1'
(destination / 'experiment.json').write_text(json.dumps(c, indent=2) + '\n')
receipt = {'capsule': str(destination), 'source_capsule': str(source), 'run_name': run_name,
           'window_started_utc': datetime.datetime.fromtimestamp(started, datetime.UTC).isoformat(),
           'deadline_utc': datetime.datetime.fromtimestamp(started + 7140, datetime.UTC).isoformat(),
           'config': c, 'status': 'staged_needs_CPU_preflight_and_final_source_manifest_not_submitted'}
(destination / 'evidence/staging.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt))
