"""CPU-only reading of retained tokens and actual Adam evidence; no model calls."""

import hashlib
import json
from pathlib import Path
from statistics import mean

from transformers import AutoTokenizer

root = Path('/evidence/run/step-0001/online_train')
rows = json.loads((root / 'selected-transitions.json').read_text())
directions = json.loads((root / 'teacher-adam-directions.json').read_text())
tokenizer = AutoTokenizer.from_pretrained(
    '/hf/hub/models--Qwen--Qwen3.5-4B/snapshots/851bf6e806efd8d0a36b00ddf55e13ccb7b8cd0a',
    local_files_only=True,
)
targets = {
    'simple.asana_sprint_section_task': ['as_rec_1', 'sec_sprint8', 'due_date', 'dueDate'],
    'sales.soft_matching': ['gmail_find_email', 'hr@nexgen.com'],
    'marketing.competitor_product_launch': ['Veloci', 'Zerion Labs', 'Lumicast', 'embargo'],
    'simple.gmail_reply_complaint': ['gmail_find_email', 'James Whitfield'],
}
output = []
for index, (row, direction) in enumerate(zip(rows, directions, strict=True)):
    assert (row['task'], row['generation_index']) == (
        direction['task'], direction['generation_index'])
    if row['task'] not in targets:
        continue
    tokens = row['action_ids']
    text = tokenizer.decode(tokens)
    ends = [len(tokenizer.decode(tokens[:i + 1])) for i in range(len(tokens))]
    starts = [0, *ends[:-1]]
    advantage = direction['teacher_sampled_advantages']
    delta = direction['actual_adam_logprob_deltas']
    assert len(advantage) == len(delta) == len(tokens)
    tool_start = text.find('<tool_call>')
    spans = []
    for term in targets[row['task']]:
        offset = 0
        while (found := text.casefold().find(term.casefold(), offset)) >= 0:
            stop = found + len(term)
            indices = [i for i, (a, b) in enumerate(zip(starts, ends, strict=True))
                       if a < stop and b > found]
            if indices:
                spans.append({
                    'term': term, 'character_offset': found,
                    'part': 'tool_call' if tool_start >= 0 and found >= tool_start else 'reasoning_or_final',
                    'token_indices': indices,
                    'mean_teacher_sampled_advantage': mean(advantage[i] for i in indices),
                    'mean_actual_adam_sampled_logprob_delta': mean(delta[i] for i in indices),
                })
            offset = stop
    output.append({
        'selected_index': index, 'task': row['task'], 'episode_id': row['episode_id'],
        'generation_index': row['generation_index'], 'native_episode_success': row['native_success'],
        'observed_tool_error': row['observed_tool_error'], 'terminal_text': row['terminal_text'],
        'action': text, 'keyword_spans': spans,
        'full_action_mean_teacher_sampled_advantage': mean(advantage),
        'full_action_mean_actual_adam_sampled_logprob_delta': mean(delta),
        'scope': 'Teacher advantage and actual Adam sampled-token deltas on forced original prefixes. '
                 'Keywords are diagnostic slices, not causal goal credit or free teacher rollouts.',
    })
print(json.dumps({
    'source_sha256': {name: hashlib.sha256((root / name).read_bytes()).hexdigest()
                      for name in ('selected-transitions.json', 'teacher-adam-directions.json')},
    'model_calls': 0, 'optimizer_updates': 0, 'decisions': output,
}, indent=2))
