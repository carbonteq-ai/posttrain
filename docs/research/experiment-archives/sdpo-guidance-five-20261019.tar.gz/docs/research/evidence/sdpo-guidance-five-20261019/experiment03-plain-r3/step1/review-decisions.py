"""Read actual token/Adam evidence, without model calls or optimizer updates."""
import hashlib
import json
from pathlib import Path
from statistics import mean

from transformers import AutoTokenizer

p = Path('/evidence/run/step-0001/online_train')
rows = json.loads((p / 'selected-transitions.json').read_text())
directions = json.loads((p / 'teacher-adam-directions.json').read_text())
tokenizer = AutoTokenizer.from_pretrained(
    '/hf/hub/models--Qwen--Qwen3.5-4B/snapshots/851bf6e806efd8d0a36b00ddf55e13ccb7b8cd0a',
    local_files_only=True,
)
targets = {
    'simple.asana_sprint_section_task': ['due_date', 'dueDate', 'as_rec_1', 'sec_sprint8'],
    'sales.soft_matching': ['gmail_find_email', 'hr@nexgen.com', 'salesforce'],
    'marketing.competitor_product_launch': ['spreadspreadsheet_id', 'spreadsheet_id', 'Veloci', 'Lumicast'],
    'simple.gmail_reply_complaint': ['gmail_find_email', 'James Whitfield'],
}
output = []
for index, (row, direction) in enumerate(zip(rows, directions, strict=True)):
    assert (row['task'], row['generation_index']) == (direction['task'], direction['generation_index'])
    if row['task'] not in targets:
        continue
    tokens = row['action_ids']
    text = tokenizer.decode(tokens)
    ends = [len(tokenizer.decode(tokens[:i + 1])) for i in range(len(tokens))]
    starts = [0, *ends[:-1]]
    a, delta = direction['teacher_sampled_advantages'], direction['actual_adam_logprob_deltas']
    support = direction['teacher_support_diagnostic']
    assert len(a) == len(delta) == len(tokens) == len(support['teacher_top1_ids'])
    tool_start = text.find('<tool_call>')
    spans = []
    for term in targets[row['task']]:
        offset = 0
        while (found := text.casefold().find(term.casefold(), offset)) >= 0:
            stop = found + len(term)
            indices = [i for i, (left, right) in enumerate(zip(starts, ends, strict=True))
                       if left < stop and right > found]
            if indices:
                spans.append({'term': term, 'character_offset': found,
                    'part': 'tool_call' if tool_start >= 0 and found >= tool_start else 'reasoning_or_final',
                    'mean_teacher_sampled_advantage': mean(a[i] for i in indices),
                    'mean_actual_adam_sampled_logprob_delta': mean(delta[i] for i in indices),
                    'tokens': [{'index': i, 'sampled': tokenizer.decode([tokens[i]]),
                        'teacher_top1': tokenizer.decode([support['teacher_top1_ids'][i]]),
                        'teacher_top1_student_rank': support['teacher_top1_student_ranks'][i],
                        'teacher_mass_on_student_top20': support['teacher_mass_on_student_support'][i],
                        'teacher_sampled_advantage': a[i], 'actual_adam_sampled_logprob_delta': delta[i],
                        'actual_adam_teacher_top1_logprob_delta': support['actual_adam_teacher_top1_logprob_deltas'][i]}
                        for i in indices]})
            offset = stop
    output.append({'selected_index': index, 'task': row['task'], 'episode_id': row['episode_id'],
        'generation_index': row['generation_index'], 'native_episode_success': row['native_success'],
        'observed_tool_error': row['observed_tool_error'], 'observed_action_risks': row.get('observed_action_risks', []),
        'terminal_text': row['terminal_text'], 'action': text, 'teacher_feedback': row['teacher_feedback'],
        'keyword_spans': spans,
        'scope': 'Local forced-prefix token diagnostics; a teacher preference is not a correctness label, '
                 'and one Adam step is not a task-outcome comparison.'})
print(json.dumps({'source_sha256': {name: hashlib.sha256((p / name).read_bytes()).hexdigest()
                                  for name in ('selected-transitions.json', 'teacher-adam-directions.json')},
                  'model_calls': 0, 'optimizer_updates': 0, 'decisions': output}, indent=2))
