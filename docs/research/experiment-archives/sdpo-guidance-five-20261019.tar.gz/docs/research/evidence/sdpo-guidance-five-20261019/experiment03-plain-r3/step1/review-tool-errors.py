"""Inspect retained failing tool actions and teacher-only future observations."""
import json
import re
from pathlib import Path

from transformers import AutoTokenizer

p = Path('/evidence/run/step-0001/online_train')
rows = json.loads((p / 'selected-transitions.json').read_text())
directions = json.loads((p / 'teacher-adam-directions.json').read_text())
t = AutoTokenizer.from_pretrained(
    '/hf/hub/models--Qwen--Qwen3.5-4B/snapshots/851bf6e806efd8d0a36b00ddf55e13ccb7b8cd0a',
    local_files_only=True,
)
result = []
for index, (r, d) in enumerate(zip(rows, directions, strict=True)):
    if not r['observed_tool_error']:
        continue
    assert (r['task'], r['generation_index']) == (d['task'], d['generation_index'])
    action = t.decode(r['action_ids'])
    prefix = t.decode(r['student_prefix_ids'])
    text = r['teacher_feedback'].split('Factual hindsight from this student episode:\n', 1)[1]
    facts = json.JSONDecoder().raw_decode(text)[0]
    observations = facts['current_action_observations']
    errors = []
    for observation in observations:
        value = observation['response']
        if isinstance(value, str):
            try:
                value = json.loads(value)
            except ValueError:
                pass
        if isinstance(value, dict):
            errors.append({'tool': observation['tool'], 'response': {
                k: v for k, v in value.items() if k in ('success', 'error', 'errors')}})
        else:
            errors.append({'tool': observation['tool'], 'response': value})
    calls = [{'tool': name, 'arguments': {k: v.strip() for k, v in
             re.findall(r'<parameter=([^>]+)>(.*?)</parameter>', body, re.S)}}
             for name, body in re.findall(r'<function=([^>]+)>(.*?)</function>', action, re.S)]
    error_text = json.dumps(errors)
    identifiers = sorted(set(re.findall(r'\b(?:ss_|ws_|msg_|proj_|ch_)[A-Za-z0-9_-]+', error_text)))
    support = d['teacher_support_diagnostic']
    ends = [len(t.decode(r['action_ids'][:i + 1])) for i in range(len(r['action_ids']))]
    start = action.find('<tool_call>')
    divergences = [i for i, end in enumerate(ends) if end > start >= 0
                   and r['action_ids'][i] != support['teacher_top1_ids'][i]]
    result.append({'selected_index': index, 'task': r['task'], 'episode_id': r['episode_id'],
        'generation_index': r['generation_index'], 'native_episode_success': r['native_success'],
        'action': action, 'parsed_calls': calls, 'observed_errors': errors,
        'identifiers_in_error_absent_from_student_prefix': [v for v in identifiers if v not in prefix],
        'first_tool_token_divergences': [{'index': i, 'sampled': t.decode([r['action_ids'][i]]),
            'teacher_top1': t.decode([support['teacher_top1_ids'][i]]),
            'teacher_top1_student_rank': support['teacher_top1_student_ranks'][i],
            'sampled_advantage': d['teacher_sampled_advantages'][i],
            'actual_adam_sampled_delta': d['actual_adam_logprob_deltas'][i]}
            for i in divergences[:12]],
        'scope': 'Future error observations can expose values not available at the original student decision. '
                 'A local token preference is not a free teacher continuation or correct recovery.'})
print(json.dumps({'model_calls': 0, 'optimizer_updates': 0, 'cases': result}, indent=2))
