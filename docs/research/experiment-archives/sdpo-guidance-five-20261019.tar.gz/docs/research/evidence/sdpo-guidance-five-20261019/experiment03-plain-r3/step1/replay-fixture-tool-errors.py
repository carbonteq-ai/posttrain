"""CPU-only isolated calls against copied frozen initial states; no repairs."""
import copy
import hashlib
import inspect
import json
from datetime import datetime
from pathlib import Path

from automationbench.tools import ALL_TOOLS
from automationbench_v1.world_codec import load_world
from pydantic import TypeAdapter

root = Path('/evidence/run/step-0001/online_train')
episodes = {e['task']['data']['name']: e for line in (root / 'native/traces.jsonl').open()
            if (e := json.loads(line))['task']['data']['name'] in
            ('simple.new_lead_sf_jira', 'simple.buffer_company_award')}
functions = {f.__name__: f for f in ALL_TOOLS}
cases = [
    ('jira_observed_mixed_aliases', 'simple.new_lead_sf_jira', 'jira_create_issue',
     {'project_key': 'SALES', 'summary': 'Follow up with Derek Huang from BrightPath Solutions', 'issuetype': 'Task'}),
    ('jira_historical_reference_aliases', 'simple.new_lead_sf_jira', 'jira_create_issue',
     {'project_key': 'SALES', 'summary': 'Follow up with Derek Huang - BrightPath Solutions', 'issue_type': 'Task'}),
    ('jira_canonical_aliases', 'simple.new_lead_sf_jira', 'jira_create_issue',
     {'project': 'SALES', 'summary': 'Follow up with Derek Huang', 'issuetype': 'Task'}),
    ('buffer_observed_date', 'simple.buffer_company_award', 'buffer_add_to_queue',
     {'organization_id': 'org_001', 'channel_id': 'ch_facebook', 'method': 'schedule',
      'text': 'BrightPath Forbes Cloud100 gratitude.', 'scheduled_at': '2024-01-12T15:00:00Z'}),
    ('buffer_historical_reference_date', 'simple.buffer_company_award', 'buffer_add_to_queue',
     {'organization_id': 'org_001', 'channel_id': 'ch_facebook', 'method': 'schedule',
      'text': 'BrightPath Forbes Cloud100 gratitude.', 'scheduled_at': '2026-10-09T14:00:00+05:00'}),
]
output = []
for label, task, tool, arguments in cases:
    initial = episodes[task]['task']['data']['initial_state']
    world = load_world(copy.deepcopy(initial))
    arguments = copy.deepcopy(arguments)
    if 'scheduled_at' in arguments:
        arguments['scheduled_at'] = TypeAdapter(datetime).validate_python(arguments['scheduled_at'])
    before = len(world.buffer.posts) if tool.startswith('buffer') else len(world.jira.project_records())
    try:
        value = json.loads(functions[tool](world, **arguments))
        outcome = {'returned': value}
    except (TypeError, ValueError) as error:
        outcome = {'raised_type': type(error).__name__, 'raised_message': str(error)}
    after = len(world.buffer.posts) if tool.startswith('buffer') else len(world.jira.project_records())
    output.append({'case': label, 'task': task, 'tool': tool, 'arguments': arguments,
        'before_count': before, 'after_count': after,
        'count_kind': 'buffer_posts' if tool.startswith('buffer') else 'jira_projects',
        'native_initial_state_sha256': hashlib.sha256(json.dumps(initial, sort_keys=True).encode()).hexdigest(),
        **outcome})
print(json.dumps({'cases': output, 'model_calls': 0, 'optimizer_updates': 0,
    'function_source_sha256': {name: hashlib.sha256(inspect.getsource(functions[name]).encode()).hexdigest()
                             for name in ('jira_create_issue', 'buffer_add_to_queue')},
    'scope': 'Isolated offline tool calls on deep-copied frozen native initial states. No running-state, '
             'dependency or fixture modification. This does not establish full-episode causal attribution.'},
    indent=2, default=str))
