import hashlib
import json
import sys
from pathlib import Path

p = Path('/var/lib/posttrain/qualifications/sdpo-guidance-five-20261019-experiment03-plain-r3')
source = p.with_name('sdpo-guidance-five-20261019-experiment02-plain-r4')
sys.path.insert(0, str(p / 'driver'))
from sdpo_shared_base import fingerprint

c = json.loads((p / 'experiment.json').read_text())
pre = json.loads((p / 'native-preflight.json').read_text())
assert pre['qualified'] and pre['sampling']['selected_risk_actions'] == 5
reference = json.loads((p / 'baseline/reference.json').read_text())
inputs = json.loads((source / 'evidence/run/inputs.json').read_text())
assert fingerprint(p / 'driver', inputs, reference['fingerprint']['initial_adapter_sha256']) == reference['fingerprint']
assert hashlib.sha256((p / 'cohorts.json').read_bytes()).hexdigest() == 'ec5a532f94a1f160471b57e60be06869121e5680f4b7415a7764895e629a76e0'
assert hashlib.sha256((p / 'guidance.json').read_bytes()).hexdigest() == '303ff95cf6f97b89ce24736437781042ef77cdf76fd5a3de8ccca38dd76fa578'
old = {f.relative_to(source / 'driver'): f for f in (source / 'driver').rglob('*.py')}
new = {f.relative_to(p / 'driver'): f for f in (p / 'driver').rglob('*.py')}
assert old.keys() == new.keys()
assert all(old[name].read_bytes() == new[name].read_bytes() for name in old)
compatibility = {
    'qualified': True, 'runtime_python_files_equal': len(old),
    'student_runtime_fingerprint_equal': True,
    'source_capsule': str(source),
    'initial_adapter_scope': 'Expected identity only; actual fresh model seed/hash is independently checked before shared-control use.',
    'preflight_sha256': hashlib.sha256((p / 'native-preflight.json').read_bytes()).hexdigest(),
    'preserved_CPU_check_correction': 'Initial inspection assumed269 root-level Python files. Actual inherited main source has272 recursive Python files; all272 names and bytes match, including exact student fingerprint. No runtime or threshold changed.',
}
(p / 'plain-source-compatibility.json').write_text(json.dumps(compatibility, indent=2) + '\n')
manifest = []
for f in sorted(p.rglob('*')):
    relative = f.relative_to(p)
    if (not f.is_file() or relative.parts[0] == 'evidence'
            or '__pycache__' in relative.parts or relative.name == 'source-sha256.txt'):
        continue
    manifest.append(hashlib.sha256(f.read_bytes()).hexdigest() + '  ' + str(relative))
(p / 'source-sha256.txt').write_text('\n'.join(manifest) + '\n')
receipt = {
    'capsule': str(p), 'run_name': c['run_name'], 'config': c,
    'source_manifest_sha256': hashlib.sha256((p / 'source-sha256.txt').read_bytes()).hexdigest(),
    'compatibility': compatibility, 'native_preflight': pre,
    'status': 'ready_not_submitted',
}
(p / 'evidence/ready-receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt))
