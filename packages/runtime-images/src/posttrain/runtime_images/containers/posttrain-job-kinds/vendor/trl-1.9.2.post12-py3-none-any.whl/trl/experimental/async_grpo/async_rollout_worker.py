# Copyright 2020-2026 The HuggingFace Team. All rights reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import asyncio
import enum
import inspect
import multiprocessing as mp
import os
import pickle
import queue
import threading
import time
import traceback
import uuid
import warnings
from collections.abc import Awaitable, Callable, Iterator
from dataclasses import dataclass, field
from multiprocessing.queues import Queue as MPQueue
from multiprocessing.sharedctypes import Synchronized as MPValue
from multiprocessing.synchronize import Event as MPEvent
from typing import Any, TypeAlias

import aiohttp
import numpy as np
from accelerate.logging import get_logger
from datasets import Dataset
from transformers import PreTrainedTokenizerBase

from ...chat_template_utils import (
    _SUPPORTS_RESPONSE_TEMPLATE,
    add_response_schema,
    get_training_chat_template,
    is_chat_template_prefix_preserving,
    parse_response,
)
from ...import_utils import is_vllm_available
from ...trainer.utils import get_callable_name, print_prompt_completions_sample


logger = get_logger(__name__)

Messages: TypeAlias = list[dict[str, str]]
RolloutId: TypeAlias = str

_RETRYABLE_HTTP_ERRORS = (aiohttp.ClientError, asyncio.TimeoutError, TimeoutError, ConnectionResetError)


async def _retry_on_http_error(coro_factory: Callable[[], Awaitable], *, label: str, max_attempts: int = 1):
    """Retry an aiohttp coroutine on transport errors with bounded exponential backoff."""
    for attempt in range(max_attempts):
        try:
            return await coro_factory()
        except _RETRYABLE_HTTP_ERRORS as e:
            if attempt >= max_attempts - 1:
                raise
            sleep = min(2 ** min(attempt, 4), 16)
            logger.warning(f"{label} failed ({type(e).__name__}: {e}); retry {attempt + 1}/{max_attempts} in {sleep}s")
            await asyncio.sleep(sleep)


@dataclass(frozen=True)
class TurnRecord:
    """One generation call: the whole prompt this turn, the tokens the model produced, their logprobs."""

    prompt_ids: list[int]
    output_ids: list[int]
    output_log_probs: list[float] = field(default_factory=list)


@dataclass
class TrainingSequence:
    """One training row. Maps 1:1 onto the list fields of `RolloutSample`."""

    input_ids: list[int]  # full tokens (prompt included)
    completion_mask: list[int]  # 1 = train this token, 0 = context
    old_log_probs: list[float]  # generator logprobs, 0.0 where mask is 0
    rollout_id: RolloutId  # which conversation this row came from


def _common_prefix_len(a: list[int], b: list[int], chunk: int = 4096) -> int:
    """How many tokens at the start are identical in `a` and `b`."""
    limit = min(len(a), len(b))
    matched = 0
    while matched < limit:
        end = min(matched + chunk, limit)
        if a[matched:end] == b[matched:end]:
            matched = end
        else:
            while matched < end and a[matched] == b[matched]:
                matched += 1
            return matched
    return matched


class DriftKind(enum.Enum):
    CLEAN = "clean"  # new prompt starts exactly with held tokens -> append the new part
    REALIGN = "realign"  # small change in the last answer -> overwrite it as context
    FORK = "fork"  # bigger change -> start a new row


class _SampleBuilder:
    def __init__(self, fork_threshold: int):
        self._fork_threshold = fork_threshold
        self.tokens: list[int] = []
        self.loss_mask: list[int] = []
        self.logprobs: list[float] = []
        self.last_response_start_idx: int | None = None

    def classify_token_drift(self, turn: TurnRecord) -> DriftKind:
        matched = _common_prefix_len(self.tokens, turn.prompt_ids)
        drift = len(self.tokens) - matched
        if drift == 0:
            return DriftKind.CLEAN
        start = self.last_response_start_idx
        if start is not None and matched >= start and drift < self._fork_threshold:
            return DriftKind.REALIGN
        return DriftKind.FORK

    def append_turn(self, turn: TurnRecord, kind: DriftKind, *, trained: bool = True) -> None:
        assert kind is not DriftKind.FORK
        if kind is DriftKind.REALIGN:
            self._align_to_prompt(turn.prompt_ids)  # overwrite drifted tail as context
        else:  # CLEAN: held tokens are a prefix of the new prompt; append the tail as context
            self._append(turn.prompt_ids[len(self.tokens) :], mask=0)
        self.last_response_start_idx = len(self.tokens)
        self._append(turn.output_ids, mask=int(trained), logprobs=turn.output_log_probs if trained else None)

    def _align_to_prompt(self, prompt_ids: list[int]) -> None:
        matched = _common_prefix_len(self.tokens, prompt_ids)
        tail = prompt_ids[matched:]
        self.tokens[matched:] = tail
        self.loss_mask[matched:] = [0] * len(tail)
        self.logprobs[matched:] = [0.0] * len(tail)

    def _append(self, ids: list[int], *, mask: int, logprobs: list[float] | None = None) -> None:
        self.tokens.extend(ids)
        self.loss_mask.extend([mask] * len(ids))
        self.logprobs.extend(logprobs if logprobs else [0.0] * len(ids))

    def has_trained_token(self) -> bool:
        return any(self.loss_mask)

    def to_training_sequence(self, rollout_id: RolloutId) -> TrainingSequence:
        return TrainingSequence(list(self.tokens), list(self.loss_mask), list(self.logprobs), rollout_id)


def _chain_to_sequences(turns: list[TurnRecord], rollout_id: RolloutId, fork_threshold: int) -> list[TrainingSequence]:
    """Reconcile one conversation's turns (in order) into training rows; fork when re-tokenization drifts."""
    builders: list[_SampleBuilder] = []
    for turn in turns:
        if not builders or (kind := builders[-1].classify_token_drift(turn)) is DriftKind.FORK:
            builder = _SampleBuilder(fork_threshold)
            builder.append_turn(turn, DriftKind.CLEAN)
            builders.append(builder)
        else:
            builders[-1].append_turn(turn, kind)
    return [b.to_training_sequence(rollout_id) for b in builders if b.has_trained_token()]


@dataclass(slots=True)
class RolloutGroup:
    prompts: list[Messages]
    reward_kwargs: dict[str, list[Any]]
    completions: list[Messages]
    completions_ids: list[list[int]]  # per conversation, its completion token stream (for reward funcs)
    completions_sequences: list[list[TrainingSequence]]  # per conversation, its 1+ training rows
    tool_call_counts: list[int]
    tool_failure_counts: list[int]
    model_version: int
    group_id: int
    env_rewards: list[tuple[type, float] | None]
    queued_at: float = 0.0


@dataclass(slots=True)
class RolloutSample:
    prompt: Messages
    completion: Messages
    input_ids: list[int]
    completion_mask: list[int]
    old_log_probs: list[float]
    advantage: float
    model_version: int
    group_id: int
    metrics: dict[str, float]


# Env vars the child must drop so accelerate's `PartialState()` initialises in
# single-process mode instead of trying to join the parent's process group.
_CHILD_ENV_TO_STRIP = (
    "RANK",
    "WORLD_SIZE",
    "LOCAL_RANK",
    "LOCAL_WORLD_SIZE",
    "MASTER_ADDR",
    "MASTER_PORT",
    "GROUP_RANK",
    "ROLE_RANK",
    "ROLE_WORLD_SIZE",
    "TORCHELASTIC_RUN_ID",
    "TORCHELASTIC_RESTART_COUNT",
    "TORCHELASTIC_MAX_RESTARTS",
    "TORCH_FR_DUMP_TEMP_FILE",
    "NCCL_DEBUG_FILE",
)


def _scrub_child_env() -> None:
    # The child has no business touching CUDA; any library that imports torch
    # and lazily probes devices would race the parent's allocator.
    os.environ["CUDA_VISIBLE_DEVICES"] = ""
    for k in _CHILD_ENV_TO_STRIP:
        os.environ.pop(k, None)


def _spawn_stop_watcher(rollout_loop: "_AsyncRolloutLoop", stop_event: MPEvent) -> None:
    # Daemon thread that translates the parent's mp.Event into the child's
    # asyncio.Event so _run_loops breaks out of its gather.
    def _watch():
        stop_event.wait()
        try:
            rollout_loop._loop.call_soon_threadsafe(rollout_loop._stop_event.set)
        except RuntimeError:
            # Loop already closed (run() returned before stop fired). Nothing to do.
            pass

    threading.Thread(target=_watch, daemon=True, name="grpo-mp-stop-watcher").start()


def _child_main(
    loop_kwargs: dict[str, Any],
    samples_queue: MPQueue,
    model_version_value: MPValue,
    stop_event: MPEvent,
    child_ready_event: MPEvent,
    heartbeat_value: MPValue,
    failed_event: MPEvent,
    exception_info_queue: MPQueue,
) -> None:
    _scrub_child_env()
    # `accelerate.logging.get_logger` requires `PartialState()` to have been called.
    from accelerate.state import PartialState

    PartialState()

    rollout_loop = _AsyncRolloutLoop(
        **loop_kwargs,
        rollout_buffer=samples_queue,
        model_version_value=model_version_value,
        heartbeat_value=heartbeat_value,
        failed_event=failed_event,
        exception_info_queue=exception_info_queue,
    )
    child_ready_event.set()
    _spawn_stop_watcher(rollout_loop, stop_event)
    try:
        rollout_loop.run()
    except Exception:
        traceback.print_exc()
        raise


class _AsyncRolloutLoop:
    """Asyncio generate and score loops. Lives entirely inside the spawned child process.

    Owns the tokenizer, dataset iterator, reward funcs, environments, and the asyncio event loop. Talks to vLLM via
    `/v1/completions`. Pushes scored `RolloutSample`s into the shared `mp.Queue` (`rollout_buffer`); reads the bumped
    policy version from the shared `mp.Value` (`model_version_value`).
    """

    def __init__(
        self,
        *,
        model_name: str,
        dataset: Dataset,
        reward_funcs: list[Callable[..., list[float]]],
        processing_class: PreTrainedTokenizerBase,
        rollout_buffer: MPQueue,
        model_version_value: MPValue,
        heartbeat_value: MPValue,
        failed_event: MPEvent,
        exception_info_queue: MPQueue,
        tools: list[Callable] | None = None,
        environment_factory: Callable[[], object] | dict[str, Callable[[], object]] | None = None,
        num_generations: int = 8,
        max_inflight_tasks: int = 128,
        queue_maxsize: int = 0,
        vllm_server_url: str = "http://localhost:8000",
        max_tokens: int = 32,
        temperature: float = 1.0,
        request_timeout: int = 120,
        chat_template_kwargs: dict[str, Any] | None = None,
        max_tool_calling_iterations: int | None = None,
        log_completions: bool = False,
        num_completions_to_print: int | None = None,
        fork_threshold_tokens: int = 1024,
    ):
        self.model_name = model_name
        self.dataset = dataset
        self._dataset_iter = iter(dataset)
        self.reward_funcs = reward_funcs
        self.reward_func_names = [get_callable_name(f) for f in reward_funcs]
        # `add_response_schema` sets the response template (transformers >= 5.13) or legacy schema for known chat
        # templates, so tool calls can be parsed. Skip if one is already set; warn if it's a migratable legacy schema.
        has_template = getattr(processing_class, "response_template", None) is not None
        has_schema = getattr(processing_class, "response_schema", None) is not None
        if not has_template and not has_schema:
            processing_class = add_response_schema(processing_class)
        elif has_schema and not has_template and _SUPPORTS_RESPONSE_TEMPLATE:
            warnings.warn(
                "The tokenizer has a legacy `response_schema` set but no `response_template`. The installed "
                "transformers supports the new-style `response_template`; consider migrating, as `response_schema` "
                "support will eventually be removed. See the Transformers response-parsing docs.",
                FutureWarning,
            )
        self.tokenizer = processing_class
        self.rollout_buffer = rollout_buffer  # shared mp.Queue
        self._model_version_value = model_version_value  # shared mp.Value
        self._heartbeat_value = heartbeat_value  # shared mp.Value('d'); wall-clock seconds
        self._failed_event = failed_event  # shared mp.Event
        self._exception_info_queue = exception_info_queue  # shared mp.Queue(maxsize=1)

        self.num_generations = num_generations
        self.max_inflight_tasks = max_inflight_tasks
        self.queue_maxsize = queue_maxsize
        self.max_tokens = max_tokens
        self.temperature = temperature
        self.request_timeout = request_timeout
        self.chat_template_kwargs = chat_template_kwargs or {}
        self.max_tool_calling_iterations = max_tool_calling_iterations
        self.log_completions = log_completions
        self.num_completions_to_print = num_completions_to_print
        self._fork_threshold_tokens = fork_threshold_tokens  # reconciler fork/realign threshold
        self.vllm_server_url = vllm_server_url.rstrip("/")

        tools = tools or []
        self._standalone_tools = tools  # tools that are not bound to an environment
        self._env_reward_types = []  # env classes that own their reward via `get_reward`; one reward column each

        # Normalize `environment_factory` to a `{name: factory}` mapping. A single callable is the special case of one
        # unnamed (`None`) environment shared by every example; a dict maps the `environment` field of each example to
        # its factory. `_multi_environment` records which case we are in: only then is the `environment` field read.
        self._multi_environment = isinstance(environment_factory, dict)
        if environment_factory is None:
            self.environment_factories = None
        elif self._multi_environment:
            self.environment_factories = environment_factory
        else:
            self.environment_factories = {None: environment_factory}

        if self.environment_factories is not None:
            # Probe one instance of each environment to validate its `reset` method and extract its tool methods, used
            # to render the per-example tool schema in the prompt. Instances are pooled and reused (reset) across
            # rollouts; the probe seeds the pool so it is not wasted. The pool grows only when more concurrent instances
            # of an environment are needed than have been created so far, preserving the "construct once, reset often"
            # contract even when rollouts mix environments.
            self._env_tools = {}  # {environment name: tools exposed when this environment is selected}
            self._environment_pool = {}  # {environment name: list of reusable instances}
            # `self.tools` is the union of every environment's tools, accumulated below as each environment is probed.
            # Used only to decide whether a training chat template is needed.
            self.tools = list(tools)
            for name, factory in self.environment_factories.items():
                instance = factory()
                has_reset = False
                methods = []
                for member_name, member in inspect.getmembers(instance, predicate=inspect.ismethod):
                    if member_name == "reset":
                        has_reset = True
                    elif member_name == "get_reward":
                        if type(instance) not in self._env_reward_types:
                            self._env_reward_types.append(type(instance))
                    elif not member_name.startswith("_"):
                        methods.append(member)
                if not has_reset:
                    raise ValueError(
                        "Each environment instance returned by `environment_factory` must define a callable `reset`."
                    )
                self._env_tools[name] = tools + methods
                self._environment_pool[name] = [instance]
                self.tools += [method for method in methods if method not in self.tools]
            # Each environment that owns its reward via `get_reward` becomes an extra reward source, named after the env
            # class (its per-rollout value is scored inline in `_generate_loop` and summed in `_score_group`). One
            # column per such class: mixing an env that owns its reward with one that does not is safe.
            for env_type in self._env_reward_types:
                self.reward_func_names.append(env_type.__name__)
        else:
            self.tools = tools

        # At least one reward source is required: either `reward_funcs`, or an environment that owns the reward via a
        # `get_reward` method.
        if not self.reward_funcs and not self._env_reward_types:
            raise ValueError(
                "No reward source provided. Pass `reward_funcs`, or an `environment_factory` whose environment "
                "defines a `get_reward` method."
            )

        # The async worker can't await tools in its tool loop, so asynchronous tools are not supported.
        for tool in self.tools:
            if inspect.iscoroutinefunction(tool):
                raise ValueError("Asynchronous tools are not supported yet.")

        # The chat template must be prefix-preserving in multi-turn training; if the tokenizer's
        # template isn't, swap in a training-safe one.
        if self.tools and not is_chat_template_prefix_preserving(self.tokenizer):
            self.chat_template = get_training_chat_template(self.tokenizer)
        else:
            self.chat_template = None

        self._groups_to_score: asyncio.Queue[RolloutGroup | None] = asyncio.Queue(maxsize=16)
        self._total_completion_tokens = 0
        self._total_groups_scored = 0
        self._generation_start_time: float | None = None
        self.session: aiohttp.ClientSession | None = None

        self._loop = asyncio.new_event_loop()
        self._stop_event = asyncio.Event()

    @property
    def model_version(self) -> int:
        return int(self._model_version_value.value)

    def run(self) -> None:
        asyncio.set_event_loop(self._loop)
        try:
            self._loop.run_until_complete(self._run_loops(stop_event=self._stop_event))
        except BaseException as e:
            # Push pickle-safe exception info to the parent before setting _failed_event, so a
            # reader that sees the event is guaranteed to also see the info on the queue.
            info = (type(e).__name__, str(e), traceback.format_exc())
            try:
                self._exception_info_queue.put_nowait(info)
            except Exception:
                pass  # queue full (parent hasn't drained a prior failure), best-effort put
            self._failed_event.set()
            logger.exception(f"Worker process failed: {e}")
            raise
        finally:
            self._loop.close()

    async def _run_loops(self, stop_event: asyncio.Event) -> None:
        async with aiohttp.ClientSession(connector=aiohttp.TCPConnector(limit=self.max_inflight_tasks)) as session:
            self.session = session
            logger.info(
                f"vllm worker started: num_generations={self.num_generations}, "
                f"max_inflight_tasks={self.max_inflight_tasks}"
            )
            await asyncio.gather(
                asyncio.create_task(self._generate_loop(stop_event=stop_event)),
                asyncio.create_task(self._score_loop(stop_event=stop_event)),
            )

    async def _generate_loop(self, stop_event: asyncio.Event) -> None:
        pending_groups: dict[int, RolloutGroup] = {}
        pending_completed: dict[int, int] = {}
        inflight_tasks: dict[asyncio.Task, tuple[int, int, Any, object, Messages]] = {}
        free_slots = set(range(self.max_inflight_tasks))
        work_iter = self._repeat_iterator()

        self._generation_start_time = time.monotonic()
        try:
            while True:
                # Wall-clock for cross-process comparison; parent uses time.time() in check_health.
                self._heartbeat_value.value = time.time()
                while free_slots and not stop_event.is_set():
                    group_id, row = next(work_iter)
                    slot = free_slots.pop()
                    # The environment is selected per example via its `environment` field (multi-env); only its tools
                    # are exposed in the example's prompt. When there are no environments, every example shares the
                    # standalone tools.
                    name = row.get("environment") if self._multi_environment else None
                    if self._multi_environment and name not in self.environment_factories:
                        raise ValueError(
                            f"Example has `environment={name!r}`, which is not among the environments passed to "
                            f"`environment_factory`. Expected one of: {list(self.environment_factories)}."
                        )
                    tools = self._env_tools[name] if self.environment_factories is not None else self.tools
                    # Draw a reusable environment instance for this rollout (creating one only if the pool is
                    # exhausted); it is returned to the pool when the task completes. Reset it BEFORE building the
                    # prompt and capture its initial observation (e.g. a task instruction). The reset() return was
                    # previously discarded, so an environment_factory whose task lives in the observation (not the
                    # dataset prompt) was generated against the bare prompt. Mirror GRPOTrainer: fold the observation
                    # into the last prompt message. reset() may be stochastic, so this is done per generation (each
                    # generation gets its own observation -> its own prompt and prompt_ids). `environment` is a control
                    # field in multi-environment mode, so it is not forwarded to `reset`.
                    environment = None
                    observation = None
                    if self.environment_factories is not None:
                        pool = self._environment_pool[name]
                        environment = pool.pop() if pool else self.environment_factories[name]()
                        reset_kwargs = (
                            {k: v for k, v in row.items() if k != "environment"} if self._multi_environment else row
                        )
                        observation = environment.reset(**reset_kwargs)
                    # `prompt` is optional only when an environment owns the data; `reset()` then supplies it. Without
                    # an environment, a missing `prompt` is a malformed dataset and must still fail fast (KeyError).
                    if "prompt" not in row and self.environment_factories is not None:
                        prompt = [{"role": "user", "content": ""}]
                    else:
                        prompt = row["prompt"]
                    if observation is not None:
                        # Rebuild the last message instead of mutating in place (as GRPOTrainer does): the
                        # same row is reused across the group's generations and across epochs. Normalize str vs
                        # list (multimodal) content the same way GRPOTrainer does before concatenating.
                        last = prompt[-1]
                        content = last["content"]
                        if isinstance(observation, list) and isinstance(content, str):
                            content = [{"type": "text", "text": content}]
                        if isinstance(observation, str) and isinstance(content, list):
                            observation = [{"type": "text", "text": observation}]
                        prompt = prompt[:-1] + [{**last, "content": content + observation}]

                    # Build this rollout's tool dict: the standalone tools plus the methods of its environment.
                    methods = []
                    if environment is not None:
                        methods = [
                            member
                            for member_name, member in inspect.getmembers(environment, predicate=inspect.ismethod)
                            if member_name not in ("reset", "get_reward") and not member_name.startswith("_")
                        ]
                    tool_dict = {tool.__name__: tool for tool in self._standalone_tools + methods}

                    if group_id not in pending_groups:
                        reward_kwargs = {
                            key: [row[key]] * self.num_generations
                            for key in row
                            if key not in {"prompt", "completion", "completion_ids"}
                        }
                        pending_groups[group_id] = RolloutGroup(
                            prompts=[],
                            reward_kwargs=reward_kwargs,
                            completions=[],
                            completions_ids=[],
                            completions_sequences=[],
                            tool_call_counts=[],
                            tool_failure_counts=[],
                            model_version=self.model_version,
                            group_id=group_id,
                            env_rewards=[],
                        )
                        pending_completed[group_id] = 0

                    task = asyncio.create_task(self._generate_one(prompt, tool_dict=tool_dict, tools=tools))
                    inflight_tasks[task] = (group_id, slot, name, environment, prompt)

                if not inflight_tasks:
                    if stop_event.is_set():
                        return
                    await asyncio.sleep(0.01)
                    continue

                done, _ = await asyncio.wait(inflight_tasks, return_when=asyncio.FIRST_COMPLETED, timeout=0.1)
                if not done:
                    continue

                for task in done:
                    group_id, slot, name, environment, prompt = inflight_tasks.pop(task)
                    free_slots.add(slot)
                    if task.exception() is not None:
                        raise task.exception()

                    (
                        completion,
                        completion_ids,
                        sequences,
                        tool_call_count,
                        tool_failure_count,
                    ) = task.result()
                    group = pending_groups[group_id]
                    group.prompts.append(prompt)
                    group.completions.append(completion)
                    group.completions_ids.append(completion_ids)
                    group.completions_sequences.append(sequences)
                    group.tool_call_counts.append(tool_call_count)
                    group.tool_failure_counts.append(tool_failure_count)
                    # The environment owns the reward: score it now, while this rollout's environment still holds its
                    # final state and before returning it to the pool. `get_reward` may be async awaiting yields to
                    # inflight requests instead of halting them. The env is returned to the pool only after scoring, so
                    # a concurrent rollout can't draw and reset it during the await. Record `(env class, reward)` so
                    # `_score_group` can place it in the matching env's reward column; rollouts whose env owns no reward
                    # record `None` (turned into NaN and ignored) to stay aligned with the group's other per-rollout lists.
                    if self._env_reward_types:
                        env_type = type(environment)
                        if env_type in self._env_reward_types:
                            get_reward = environment.get_reward
                            reward = await get_reward() if inspect.iscoroutinefunction(get_reward) else get_reward()
                            group.env_rewards.append((env_type, reward))
                        else:
                            group.env_rewards.append(None)
                    if environment is not None:
                        self._environment_pool[name].append(environment)
                    self._total_completion_tokens += sum(sum(s.completion_mask) for s in sequences)
                    pending_completed[group_id] += 1

                    if pending_completed[group_id] == self.num_generations:
                        group.queued_at = time.monotonic()
                        while True:
                            try:
                                self._groups_to_score.put_nowait(group)
                                break
                            except asyncio.QueueFull:
                                if stop_event.is_set():
                                    return
                                await asyncio.sleep(0.1)
                        del pending_groups[group_id]
                        del pending_completed[group_id]
        finally:
            for task in inflight_tasks:
                task.cancel()
            if inflight_tasks:
                await asyncio.gather(*inflight_tasks, return_exceptions=True)
            try:
                self._groups_to_score.put_nowait(None)
            except asyncio.QueueFull:
                pass

    async def _score_loop(self, stop_event: asyncio.Event) -> None:
        while not stop_event.is_set():
            self._heartbeat_value.value = time.time()
            t_wait = time.monotonic()
            try:
                group = await asyncio.wait_for(self._groups_to_score.get(), timeout=0.5)
            except asyncio.TimeoutError:
                continue
            if group is None:
                return
            score_queue_wait = time.monotonic() - t_wait
            wait_scoring = time.monotonic() - group.queued_at

            if score_queue_wait > 0.5:
                logger.info(f"[score] waited {score_queue_wait:.1f}s for a group to score")

            t0 = time.monotonic()
            samples = await self._score_group(group)
            scoring_time = time.monotonic() - t0
            logger.info(
                f"[score] scored {len(samples)} samples in {scoring_time:.2f}s, "
                f"buffer_qsize={self.rollout_buffer.qsize()}"
            )

            self._compute_rollout_metrics(samples, scoring_time, wait_scoring)

            if self.log_completions and samples:
                print_prompt_completions_sample(
                    prompts=[s.prompt for s in samples],
                    completions=[s.completion for s in samples],
                    rewards={"reward": [s.metrics["reward"] for s in samples]},
                    advantages=[s.advantage for s in samples],
                    step=self._total_groups_scored,
                    num_samples=self.num_completions_to_print,
                )
            self._total_groups_scored += 1

            for sample in samples:
                while True:
                    try:
                        self.rollout_buffer.put_nowait(sample)
                        break
                    except queue.Full:
                        if stop_event.is_set():
                            return
                        logger.info(
                            f"[score] rollout buffer full (maxsize={self.queue_maxsize}), "
                            "waiting for trainer to consume..."
                        )
                        await asyncio.sleep(0.1)

    def _compute_rollout_metrics(self, samples: list[RolloutSample], scoring_time: float, wait_scoring: float) -> None:
        assert self._generation_start_time is not None
        elapsed = time.monotonic() - self._generation_start_time
        generation_tok_per_sec = self._total_completion_tokens / elapsed if elapsed > 0 else 0.0
        for sample in samples:
            sample.metrics["generation_tok_per_s"] = generation_tok_per_sec
            sample.metrics["scoring_time_ms"] = scoring_time * 1000
            sample.metrics["wait_scoring_ms"] = wait_scoring * 1000
            sample.metrics["buffer_qsize"] = self.rollout_buffer.qsize()

    def _repeat_iterator(self) -> Iterator[tuple[int, dict[str, Any]]]:
        group_id = 0
        while True:
            try:
                row = next(self._dataset_iter)
            except StopIteration:
                self._dataset_iter = iter(self.dataset)
                row = next(self._dataset_iter)
            for _ in range(self.num_generations):
                yield group_id, row
            group_id += 1

    async def _generate_one(
        self, prompt: Messages, tool_dict: dict[str, Callable], tools: list[Callable]
    ) -> tuple[list[dict[str, str]], list[int], list[TrainingSequence], int, int]:
        """Roll out one conversation, re-tokenizing the whole message list each turn and reconciling drift.

        Every turn renders the full conversation through the chat template, generates, records the turn, and feeds the
        tool result back as a message (re-tokenized on the next whole-conversation pass). At the end,
        `_chain_to_sequences` reconciles re-tokenization drift into one or more training rows: a clean append stays one
        row, a rewrite (dropped reasoning, summarized history) forks a new row. Rebuilding `prompt_ids` from the
        message list each turn (instead of gluing tokens on the end and never looking back) is what lets the reconciler
        catch rewrites. Returns the completion messages, their token ids, and the reconciled training rows (each row
        carries its own `input_ids`).
        """
        messages = list(prompt)  # a MESSAGE list, not a token list
        rollout_id = uuid.uuid4().hex
        turns: list[TurnRecord] = []
        completion, completion_ids = [], []
        tool_call_count = 0
        tool_failure_count = 0
        iteration_num = 0
        max_iterations = self.max_tool_calling_iterations
        while True:
            prompt_ids = self.tokenizer.apply_chat_template(  # re-tokenize the WHOLE conversation
                messages,
                return_dict=False,
                add_generation_prompt=True,
                tools=tools or None,
                chat_template=self.chat_template,
                **self.chat_template_kwargs,
            )
            turn_ids, turn_logprobs = await self._generate_one_turn(prompt_ids)
            assistant_message = parse_response(self.tokenizer, turn_ids, prefix=prompt_ids)
            completion.append(assistant_message)
            completion_ids.extend(turn_ids)
            messages.append(assistant_message)
            turns.append(TurnRecord(prompt_ids, turn_ids, turn_logprobs))
            tool_calls = assistant_message.get("tool_calls")
            if tool_calls is None or (max_iterations is not None and iteration_num >= max_iterations):
                break
            tool_messages, n_calls, n_failures = self._execute_tool_calls(tool_calls, tool_dict)
            tool_call_count += n_calls
            tool_failure_count += n_failures
            completion.extend(tool_messages)
            messages.extend(tool_messages)  # tool result goes back as a MESSAGE, re-tokenized next turn
            iteration_num += 1
        sequences = _chain_to_sequences(turns, rollout_id, self._fork_threshold_tokens)  # >= 1 row per conversation
        return completion, completion_ids, sequences, tool_call_count, tool_failure_count

    def _execute_tool_calls(
        self, tool_calls: list[dict[str, Any]], tool_dict: dict[str, Callable]
    ) -> tuple[list[dict[str, str]], int, int]:
        tool_messages = []
        n_calls = 0
        n_failures = 0
        for tool_call in tool_calls:
            n_calls += 1
            function = tool_call["function"]
            name = function["name"]
            try:
                arguments = function.get("arguments", {})
                result = tool_dict[name](**arguments)
            except Exception as error:
                n_failures += 1
                result = {"error": str(error)}
            tool_messages.append({"role": "tool", "name": name, "content": str(result)})
        return tool_messages, n_calls, n_failures

    async def _generate_one_turn(self, prompt_ids: list[int]) -> tuple[list[int], list[float]]:
        payload = {
            "model": self.model_name,
            "prompt": prompt_ids,
            "max_tokens": self.max_tokens,
            "temperature": self.temperature,
            "n": 1,
            "return_token_ids": True,
            "logprobs": 0,
        }
        output = await _retry_on_http_error(
            lambda: self._post("/v1/completions", payload, self.request_timeout),
            max_attempts=30,
            label="vllm /v1/completions",
        )
        choice = output["choices"][0]
        return choice["token_ids"], choice["logprobs"]["token_logprobs"]

    async def _score_group(self, group: RolloutGroup) -> list[RolloutSample]:
        kwargs = dict(
            completions=group.completions,
            prompts=group.prompts,
            completion_ids=group.completions_ids,
            **group.reward_kwargs,
        )
        all_rewards = await asyncio.gather(
            *[
                reward_func(**kwargs)
                if inspect.iscoroutinefunction(reward_func)
                else asyncio.to_thread(reward_func, **kwargs)
                for reward_func in self.reward_funcs
            ]
        )
        # Each environment that owns its reward contributes one reward column (named after its env class, in
        # `_env_reward_types` order to match `reward_func_names`), summed in with weight 1 like any reward func. Scores
        # were captured per rollout at generation time in `group.env_rewards` as `(env class, reward)`; a rollout is
        # placed in a column only when its env is that class, so mixing reward-owning and plain envs is safe.
        for env_type in self._env_reward_types:
            column = [r[1] if (r is not None and r[0] is env_type) else None for r in group.env_rewards]
            all_rewards = [*all_rewards, column]

        # Reward funcs may return None per-sample (unparseable gold). Convert to NaN. A completion
        # for which every func returned None is unscorable: nansum would give 0 and the row would
        # pull the policy away from actually-correct answers.
        # Mark such rows NaN, then compute advantage on the scorable subset only.
        all_rewards = [[r if r is not None else float("nan") for r in row] for row in all_rewards]
        arr = np.array(all_rewards, dtype=float)
        all_nan_mask = np.all(np.isnan(arr), axis=0)
        rewards = np.nansum(arr, axis=0)
        rewards[all_nan_mask] = np.nan

        scored_mask = ~np.isnan(rewards)
        # NOTE: for NaN reward we set advantage to 0 !
        advantages = np.zeros_like(rewards)
        if scored_mask.any():
            scored = rewards[scored_mask]
            advantages[scored_mask] = (scored - scored.mean()) / (scored.std() + 1e-8)
            reward_mean = float(scored.mean())
            reward_std = float(scored.std())
        else:
            reward_mean = reward_std = float("nan")
        logger.info(f"Rollout metrics: reward_mean={reward_mean:.4f}, reward_std={reward_std:.4f}")

        total_calls = sum(group.tool_call_counts)
        tool_metrics = (
            [
                {
                    "tools/call_frequency": float(n_calls),
                    "tools/failure_frequency": (n_failures / n_calls) if n_calls > 0 else 0.0,
                }
                for n_calls, n_failures in zip(group.tool_call_counts, group.tool_failure_counts, strict=True)
            ]
            if total_calls > 0
            else [{}] * len(group.completions)
        )

        per_func_rewards = np.array(all_rewards, dtype=float)
        # Option 3 advantage: one advantage per conversation, stamped on every training row it produced.
        # Under TRL's global token-mean loss a fork is invisible to the loss (see slime_research.md B.5),
        # so we do not split the reward or the advantage across a conversation's rows.
        samples = []
        for i, (prompt, completion, sequences, advantage, reward, tm) in enumerate(
            zip(
                group.prompts,
                group.completions,
                group.completions_sequences,
                advantages,
                rewards,
                tool_metrics,
                strict=True,
            )
        ):
            metrics = {
                "reward": float(reward),
                "reward_std": reward_std,
                **{
                    f"rewards/{name}": float(func_reward)
                    for name, func_reward in zip(self.reward_func_names, per_func_rewards[:, i], strict=True)
                },
                **tm,
            }
            for seq in sequences:
                samples.append(
                    RolloutSample(
                        prompt=prompt,
                        completion=completion,
                        input_ids=seq.input_ids,
                        completion_mask=seq.completion_mask,
                        old_log_probs=seq.old_log_probs,
                        advantage=float(advantage),
                        model_version=group.model_version,
                        group_id=group.group_id,
                        metrics=dict(metrics),  # own copy per row; _compute_rollout_metrics mutates it
                    )
                )
        return samples

    async def _post(self, path: str, payload: dict, timeout: float, max_retries: int = 3) -> dict:
        client_timeout = aiohttp.ClientTimeout(total=timeout)

        async def _do_post():
            async with self.session.post(
                f"{self.vllm_server_url}{path}", json=payload, timeout=client_timeout
            ) as response:
                response.raise_for_status()
                content = await response.json()
                return content if content else {}

        return await _retry_on_http_error(_do_post, label=f"POST {path}", max_attempts=max_retries)


class AsyncRolloutWorker:
    """Parent-side controller: spawns a child process running `_AsyncRolloutLoop`.

    The trainer holds this object on rank 0. The child does the actual rollout work; this class only manages lifecycle
    (start/stop) and exposes the shared `mp.Queue` (`rollout_buffer`) and `mp.Value` (`model_version`) the trainer
    reads/writes.

    Constructor kwargs are forwarded as-is to `_AsyncRolloutLoop` when the child spawns; only `queue_maxsize` and
    `child_ready_timeout` are consumed here. Because the child is spawned, every forwarded kwarg is pickled:
    `reward_funcs`, `tools`, and `environment_factory` (and anything they close over) must be picklable — module-level
    functions, `functools.partial`, or callable instances, never lambdas or closures. `start()` validates this up front
    and raises a `TypeError` otherwise. The child also runs with `CUDA_VISIBLE_DEVICES=""`, so GPU reward models
    execute on CPU.
    """

    def __init__(
        self,
        *,
        queue_maxsize: int = 0,
        child_ready_timeout: int = 300,
        **loop_kwargs: Any,
    ):
        if not is_vllm_available(min_version="0.17.1"):
            raise ImportError(
                "vLLM >= 0.17.1 is required to use AsyncRolloutWorker. Install it with: pip install 'vllm>=0.17.1'"
            )
        ctx = mp.get_context("spawn")
        self._mp_ctx = ctx
        self.rollout_buffer = ctx.Queue(maxsize=queue_maxsize)
        self._model_version_value = ctx.Value("i", 0)
        self._stop_event_mp = ctx.Event()
        self._child_ready_event = ctx.Event()
        # Liveness state shared with the child. Wall-clock seconds because monotonic() is per-process.
        self._heartbeat_value = ctx.Value("d", 0.0)
        self._failed_event = ctx.Event()
        self._exception_info_queue = ctx.Queue(maxsize=1)
        # Forwarded verbatim to _AsyncRolloutLoop in the child. queue_maxsize is also
        # forwarded — the child reads it for "rollout buffer full" log lines.
        loop_kwargs["queue_maxsize"] = queue_maxsize
        self._loop_kwargs = loop_kwargs
        self._child_ready_timeout = child_ready_timeout
        self._process: mp.Process | None = None

    @property
    def model_version(self) -> int:
        return int(self._model_version_value.value)

    @model_version.setter
    def model_version(self, value: int) -> None:
        # NOTE(@aminediro) Read/write ops like += are not atomic with mp.Value
        with self._model_version_value.get_lock():
            self._model_version_value.value = int(value)

    def update_model_version(self, model_version: int) -> None:
        self.model_version = model_version

    def start(self) -> None:
        if self._process is not None:
            logger.warning("AsyncRolloutWorker.start() called but child process is already running; ignoring.")
            return
        # Reset so spawn-import latency (~tens of seconds) doesn't immediately trip check_health.
        self._heartbeat_value.value = time.time()
        try:
            pickle.dumps(self._loop_kwargs)
        except (pickle.PicklingError, AttributeError, TypeError) as e:
            # fails fast with an actionable message instead of an opaque traceback
            raise TypeError(
                "AsyncRolloutWorker forwards reward_funcs / tools / environment_factory to a spawned "
                "child process, so they must be picklable. Lambdas and closures are not: use a "
                "module-level function, functools.partial, or a callable class instance instead."
            ) from e
        self._process = self._mp_ctx.Process(
            target=_child_main,
            args=(
                self._loop_kwargs,
                self.rollout_buffer,
                self._model_version_value,
                self._stop_event_mp,
                self._child_ready_event,
                self._heartbeat_value,
                self._failed_event,
                self._exception_info_queue,
            ),
            name="grpo-rollout-worker-child",
            daemon=True,
        )
        self._process.start()
        logger.info(
            f"AsyncRolloutWorker spawned child pid={self._process.pid}; "
            f"waiting up to {self._child_ready_timeout}s for the ready signal"
        )
        # spawn re-imports torch+transformers+trl+vllm in the child — slow on cold launch. Poll
        # liveness so an early crash surfaces immediately instead of after the full timeout.
        deadline = time.monotonic() + self._child_ready_timeout
        while not self._child_ready_event.wait(timeout=1.0):
            if not self._process.is_alive():
                exit_code = self._process.exitcode
                self._process = None
                raise RuntimeError(
                    f"AsyncRolloutWorker child exited during init (exitcode={exit_code}). "
                    "Check the child's stderr for the traceback."
                )
            if time.monotonic() >= deadline:
                raise RuntimeError(
                    f"AsyncRolloutWorker child did not signal ready within {self._child_ready_timeout}s."
                )
        logger.info("AsyncRolloutWorker child is ready")

    def check_health(self, stale_after_s: float) -> None:
        """Raise if the child crashed or hasn't ticked the heartbeat within `stale_after_s`."""
        if self._failed_event.is_set():
            try:
                type_name, msg, tb = self._exception_info_queue.get_nowait()
                cause = RuntimeError(f"{type_name}: {msg}\n{tb}")
            except queue.Empty:
                cause = None
            raise RuntimeError("Rollout worker child has failed; see chained exception.") from cause
        age = time.time() - self._heartbeat_value.value
        if age > stale_after_s:
            raise RuntimeError(f"Rollout worker heartbeat stale: {age:.0f}s > {stale_after_s:.0f}s; child is hung.")

    def stop(self) -> None:
        if self._process is None:
            return
        logger.info("Stopping AsyncRolloutWorker child process...")
        self._stop_event_mp.set()
        # If start() raised before Process.start() returned (e.g. pickle failure during spawn),
        # _popen is None and .join() would assert — skip cleanly.
        if self._process._popen is not None:
            self._process.join(timeout=15)
            if self._process.is_alive():
                logger.warning("Child did not exit within 15s; terminating.")
                self._process.terminate()
                self._process.join(timeout=5)
                if self._process.is_alive():
                    self._process.kill()
        self._process = None
