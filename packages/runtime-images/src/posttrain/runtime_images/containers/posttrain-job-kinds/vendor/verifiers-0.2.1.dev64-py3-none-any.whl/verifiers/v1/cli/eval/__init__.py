"""Evaluation CLI."""
